/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/01
 * QQ/Tel/Mail:
 * Description:管理程序启动后的各种逻辑～～登录->主页 ||
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import CoreData

class QFManagerDisplay: NSObject {

    
    //登录成功后的根视图切换
    func loginOrRegisterSuccess(){
        let root = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "root")
        UIApplication.shared.keyWindow!.rootViewController = root
    }
    
    //MARK:主页
    func displayHomepage(){
        let window = (UIApplication.shared.delegate as! AppDelegate).window
        let root = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "root")
        window!.rootViewController = root
    }
    
    //MARK:登录页
    func displayLogin(){
        let loginvc = QFLoginViewController()
        createNavigation(root: loginvc)
    }
    
    
    //MARK:显示资料填充页
    func displayGuide(){
    
        let guide = QFGuideViewController()
        createNavigation(root: guide)
    }
    
    //MARK:设置导航条
    private func createNavigation(root:UIViewController){
        let window = (UIApplication.shared.delegate as! AppDelegate).window
        let nav = UINavigationController.init(rootViewController: root)
        nav.navigationBar.isTranslucent = false
        UIBarButtonItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName:UIColor.white], for: UIControlState.normal)
        nav.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.init(red: 128 / 255.0, green: 181 / 255.0, blue: 23 / 255.0, alpha: 1)]
        nav.navigationBar.tintColor = UIColor.textInputBackground
        window!.rootViewController = nav
    }
    
    //是否显示为登录页还是主页
    func displayLoginOrHomePage(){
        //从数据库中查找是否有用户 如果有则显示主页 否则显示登录页
        //如果有登录信息则直接进入首页
        guard let result = QFDatabase.shared.fetchedResultsController(with: "Login", sortKey: "token") else{
            
            //数据库报错
            assertionFailure("数据库报获取到的result报错")
            displayLogin()
            return
        }
        
        do {
            try result.performFetch()
            let objs = result.fetchedObjects
                
            if objs != nil, objs!.count > 0 {
                displayHomepage()
            }else{
                    
                displayLogin()
            }
        } catch let error {
                assertionFailure("\(error)")
                displayLogin()
        }
    }
    
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
    
}
