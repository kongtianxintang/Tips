/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/02
 * QQ/Tel/Mail:
 * Description:数据库
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import CoreData

class QFDatabase: NSObject {

    //数据库model
    private var objectModel:NSManagedObjectModel?
    //调度员
    private var storeCoordinator:NSPersistentStoreCoordinator?
    //上下文
    private var context:NSManagedObjectContext?
    //单例
    static let shared = QFDatabase()
    
    
    
    //创建model
    private func createObjectModel()->NSManagedObjectModel?{
        if objectModel != nil{
            return objectModel!
        }
        let modelUrl = Bundle.main.url(forResource: "QFood", withExtension: "momd")
        objectModel = NSManagedObjectModel.init(contentsOf: modelUrl!)
        return objectModel
    }
    
    //创建NSPersistentStoreCoordinator
    private func createStoreCoordinator()->NSPersistentStoreCoordinator?{
        if storeCoordinator != nil{
            return storeCoordinator
        }
        let path = QFFilemanager.sharedManager.getCompanyNameDirectory() + "/QFdatabase.CDBStore"
        if !QFFilemanager.sharedManager.fileIsExists(path: path){
            
            let isSueccess = QFFilemanager.sharedManager.sysFileManager.createFile(atPath: path, contents: nil, attributes: nil)
            if !isSueccess {
                return nil
            }
            
        }
        
        let options = [NSMigratePersistentStoresAutomaticallyOption:true,NSInferMappingModelAutomaticallyOption:true]
        guard let  model = createObjectModel() else { return nil }
        storeCoordinator = NSPersistentStoreCoordinator.init(managedObjectModel: model)
        
        do{
            let url = URL.init(fileURLWithPath: path)
            let _ = try  storeCoordinator!.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: url, options: options)
        }catch {
            assertionFailure("创建调度员失败=\(error)")
            return nil
        }
        return storeCoordinator
    }
    
    //创建上下文
    func createContext()->NSManagedObjectContext?{
        
        if context != nil {
            return context!
        }
        
        
        let coordinator = createStoreCoordinator()
        
        if coordinator == nil {
            return nil
        }
        
        context = NSManagedObjectContext.init(concurrencyType: NSManagedObjectContextConcurrencyType.mainQueueConcurrencyType)
        context!.persistentStoreCoordinator = coordinator
        return context!
        
    }
    
    
    func fetchedResultsController(with name:String,sortKey:String)->NSFetchedResultsController<NSFetchRequestResult>?{
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init()
        
        guard let tempcontext = createContext() else {  return nil }
        
        let entity = NSEntityDescription.entity(forEntityName: name, in:tempcontext)
        let sort = NSSortDescriptor.init(key: sortKey, ascending: true)
        fetchRequest.entity = entity
        fetchRequest.sortDescriptors = [sort]
        let results = NSFetchedResultsController.init(fetchRequest: fetchRequest, managedObjectContext:tempcontext, sectionNameKeyPath: nil, cacheName: nil)
        
        return results
    }
    
}
