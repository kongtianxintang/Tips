/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/02
 * QQ/Tel/Mail:
 * Description:文件管理
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFFilemanager: NSObject {

    
    static let sharedManager = QFFilemanager()
    
    override init() {
        super.init()
        createCompanyNameDirectory()
    }
    
    //缓存目录
    private let caches = "/Caches"
    //公司目录
    private let name = "/QF"
    //录音目录
    private let record = "/Record"
    //系统自带文件管理
    lazy var sysFileManager = FileManager.default
    //library路径
    private let libraryPath = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true).last!
    //缓存目录
    //    private let caches = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).last!
    
    //创建公司目录
    func createCompanyNameDirectory(){
        
        let path = getCompanyNameDirectory()
        do{
            try sysFileManager.createDirectory(atPath:path, withIntermediateDirectories: true, attributes: nil)
            
        }catch{
            assertionFailure("创建公司目录失败=\(error)")
        }
    }
    
    //创建存放录音的文件夹
    func createRecord(){
        let path = getRecordPath()
        do{
            try sysFileManager.createDirectory(atPath:path, withIntermediateDirectories: true, attributes: nil)
            
        }catch{
            assertionFailure("创建文件失败=\(error)")
        }
    }
    
    //获取录音路径
    func getRecordPath()->String{
        return libraryPath + caches + name +  record
    }
    
    //文件是否存在
    func fileIsExists(path:String)->Bool{
        return sysFileManager.fileExists(atPath: path, isDirectory: nil)
    }
    
    //返回一个缓存目录
    func getCaches() -> String {
        return libraryPath + caches
    }
    
    //返回公司文件夹
    func getCompanyNameDirectory()->String{
        return libraryPath + caches + name
    }

}
