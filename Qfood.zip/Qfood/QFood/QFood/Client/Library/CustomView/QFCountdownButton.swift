/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/04
 * QQ/Tel/Mail:
 * Description:倒计时button
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFCountdownButton: UIButton {

    private var timer:Timer?
    
    private lazy var count : Int = 60;
    
    func startTimer(){
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(performCountdown), userInfo: nil, repeats: true)
        
        timer!.fire()
    }

    
    func performCountdown(){
    
        count -= 1
        
        isEnabled = false

        if count <= 0 {
            isEnabled = true
            timer!.invalidate()
            count = 60
            timer = nil
        }else{
            let desc = "剩余\(count)秒"
            titleLabel?.text = desc
            setTitle(desc, for: .disabled)
        }
        
    }
    deinit {
        if timer != nil {
            timer!.invalidate()
        }
    }
}
