/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:自定义checkbox
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

//类似uicollectionview的代理方法
@objc protocol QFCheckBoxDelegate:NSObjectProtocol {
    
    func numberOfSections()->Int
    func checkbox(numberOfItemsInSection section:Int)->Int
    func checkbox(checkbox:QFCheckBox, cellForItem indexPath:IndexPath)->UICollectionViewCell
    @objc optional func checkbox(checkbox:QFCheckBox,didSelectItemAt indexPath: IndexPath)
    @objc optional func checkbox(checkbox:QFCheckBox,didDeselectItemAt indexPath: IndexPath)
}

class QFCheckBox: UIView,UICollectionViewDelegate,UICollectionViewDataSource {

    private lazy final var reuseID = "checkboxcell"
    
    open weak var  delegate:QFCheckBoxDelegate?
    
    private var collectionview:UICollectionView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        configSubviews()
    }

    override func layoutSubviews() {
        
        collectionview.frame = bounds
    }
    
    private func configSubviews(){
        
        let flow = UICollectionViewFlowLayout()
        flow.scrollDirection = .horizontal
        let size = self.bounds.size
        let itemsize = CGSize.init(width: size.width / 2, height: size.height)
        flow.itemSize = itemsize
        flow.minimumLineSpacing = 0
//        flow.minimumInteritemSpacing = 0
        collectionview = UICollectionView.init(frame: CGRect.zero, collectionViewLayout: flow)
        collectionview.backgroundColor = UIColor.clear
        collectionview.delegate = self
        collectionview.dataSource = self
        self.addSubview(collectionview)
        registerCell()
    }
    
    deinit {
//        debugPrint("deinit~\(self.classForCoder)")
        collectionview.removeFromSuperview()
    }
    
    
    
    //#uicollectionview的代理方法
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        guard let temp = delegate else {
            return 0
        }
        return temp.numberOfSections()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return delegate!.checkbox(numberOfItemsInSection:section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        return delegate!.checkbox(checkbox:self,cellForItem: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate!.checkbox?(checkbox:self,didSelectItemAt: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        delegate!.checkbox?(checkbox: self, didDeselectItemAt: indexPath)
    }
    //#~~~cell
    func cellForItem(at indexPath:IndexPath)->UICollectionViewCell?{
        return collectionview.cellForItem(at: indexPath)
    }
    func registerCell(){
        collectionview.register(UINib.init(nibName:"QFCheckBoxCell", bundle: nil), forCellWithReuseIdentifier: reuseID)
    }
    
    func dequeueReusablecell(cellForItemAt indexPath: IndexPath)->UICollectionViewCell{
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: reuseID, for: indexPath)
        return cell
    }
}
