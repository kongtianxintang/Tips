/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/22
 * QQ/Tel/Mail:
 * Description:与秤同步数据
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import CoreBluetooth

class QFScaleController: UIViewController ,CBCentralManagerDelegate{

    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var syncInfoButton: UIButton!
    @IBOutlet weak var syncBackground: UIView!
    @IBOutlet weak var syncDesc: UILabel!
    @IBOutlet weak var syncLoading: UIImageView!
    var strongSelf:UIViewController?
    
    var callback:((_ result:TFScaleResult)->Void)?
    var failureBlock:(()->Void)?
    
    var manager:CBCentralManager?
    
    convenience init(){
        self.init(nibName:"QFScaleController",bundle: Bundle.main)
        strongSelf = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let noraml = [NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground]
        let desc = NSMutableAttributedString.init(string: "正在评测\n", attributes: noraml)
        let p = NSAttributedString.init(string: "请稍等", attributes: noraml)
        desc.append(p)
        syncDesc.attributedText = desc

        
        manager = CBCentralManager.init(delegate: self, queue: DispatchQueue.main)
        
        // Do any additional setup after loading the view.
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        let bounds = UIScreen.main.bounds
        view.frame = bounds
    }
    
    func showScaleController(){
        
        let window = UIApplication.shared.keyWindow!
        window.addSubview(view)
        window.bringSubview(toFront: view)
        contentView.transformAnimate()
        
    }
    
    @IBAction func didClickClose(_ sender: UIButton) {
        hidden()
    }

    
    //MARK:与秤同步信息
    @IBAction func didClickSyncInfo(_ sender: UIButton) {

        switch manager!.state {
        case .poweredOn:
            syncInfo()
        default:
            if failureBlock != nil {
                hidden()
                failureBlock!()
            }
            break;
        }
        
       
    }
    
    private func hidden(){
        strongSelf = nil
        view.removeFromSuperview()
    }
    
    
    private func syncInfo(){
    
        syncInfoButton.isHidden = true
        syncBackground.isHidden = false
        syncLoading.rotationAnimation()
        //先扫描
        TFScaleManager.scanDevice(withTimeut: 5, deviceTypeOptions: .all) { (devices:[Any]?, isTimeout:Bool, error:Error?) in
            
            if devices != nil{
                //延迟2秒
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
                    
                    if let user = User.contextFetchUser(){
                        if user.birthday != nil {
                            
                            let formatter = DateFormatter()
                            formatter.dateFormat = "yyyy-MM"
                            if let date = formatter.date(from: user.birthday!){
                                
                                let old = Calendar.current.component(.year, from: date)
                                let now = Calendar.current.component(.year, from: Date())
                                var age = UInt(now - old)
                                
                                if age <= 14 {
                                    age = 24
                                }
                                
                                let gender = user.sex == 1 ? true : false
                                
                                var height = UInt(user.height)
                                if height == 0 {
                                    height = 170
                                }
                                
                                TFScaleManager.startScale(withAge: age, gender: gender, height: height, deviceTypeOptions: .all, timeOut: 10.0, complete: {[unowned self] (result:TFScaleResult?, error:Error?) in

                                    TFScaleManager.stopScaleOrScan()
                                    //失败
                                    if error != nil{
                                        self.syncInfoButton.isHidden = false
                                        self.syncBackground.isHidden = true
                                        self.syncInfoButton.setTitle("同步失败,请重试", for: .normal)
                                    }else{
                                        //回调
                                        if result != nil , self.callback != nil {
                                            self.callback!(result!)
                                            self.hidden()
                                        }
                                    }
                                })
                            }
                        }
                    }else{
                        DispatchQueue.main.async {
                            self.hidden()
                            QFHubManager.showToast(nil, text: "请到设置页更新身高、年龄数据")
                        }
                    }
                    
                }
                
            }
        }
        
        
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
    }
    
}
