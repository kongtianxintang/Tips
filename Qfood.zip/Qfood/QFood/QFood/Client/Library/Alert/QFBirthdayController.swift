/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/16
 * QQ/Tel/Mail:
 * Description:选生日
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFBirthdayController: UIViewController {

    
    var strongSelf:UIViewController?
    
    var pickDateBlock:((_ date:Date)->Void)?
    
    @IBOutlet weak var datepicker: UIDatePicker!
    @IBOutlet weak var contentView: UIView!
    
    convenience init(){
        self.init(nibName:"QFBirthdayController",bundle: Bundle.main)
        strongSelf = self
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    
    override func viewDidLayoutSubviews() {
        let bounds = UIScreen.main.bounds
        view.frame = bounds
    }
    //弹框
    func showDatePick(){
        showBaseDatePick()
        datepicker.maximumDate = Date()
    }
    
    func showDatePick(withMinDate date:Date?){
        
        showBaseDatePick()
        
        datepicker.minimumDate = date
        
    }
    
    private func showBaseDatePick(){
    
        let window = UIApplication.shared.keyWindow!
        window.addSubview(view)
        window.bringSubview(toFront: view)
        contentView.transformAnimate()
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func didClickSure(_ sender: Any) {
        strongSelf = nil
        view.removeFromSuperview()
        if pickDateBlock != nil {
            pickDateBlock!(datepicker.date)
        }
        
    }
    
    @IBAction func didClickClose(_ sender: Any) {
        strongSelf = nil
        view.removeFromSuperview()
    }

}
