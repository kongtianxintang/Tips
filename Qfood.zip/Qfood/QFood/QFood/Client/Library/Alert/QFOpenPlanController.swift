/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/22
 * QQ/Tel/Mail:
 * Description:选择日期和输入产品码
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFOpenPlanController: UIViewController {
    
    @IBOutlet weak var inputTextfield: UITextField!
    @IBOutlet weak var dateButton: UIButton!
    @IBOutlet weak var contentView: UIView!
    var strongSelf:UIViewController?
    
    private var future:Date?
    
    var callback:((_ date:String,_ number:String)->Void)?
    
    convenience init(){
        self.init(nibName:"QFOpenPlanController",bundle: Bundle.main)
        strongSelf = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        dateButton.layer.cornerRadius = 4
        dateButton.layer.borderColor = UIColor.textInputBackground.cgColor
        dateButton.layer.borderWidth = 0.5
        
        inputTextfield.layer.cornerRadius = 4
        inputTextfield.layer.borderColor = UIColor.textInputBackground.cgColor
        inputTextfield.layer.borderWidth = 0.5
        
        
        var components = DateComponents()
        components.day = 1
        future = Calendar.current.date(byAdding: components, to: Date(), wrappingComponents: false)
        
        let today = Date()
        dateButton.setTitle(today.stringValue, for: .normal)

    }
    
    override func viewDidLayoutSubviews() {
        let bounds = UIScreen.main.bounds
        view.frame = bounds
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    private func hidden(){
        strongSelf = nil
        view.removeFromSuperview()
    }
    
    @IBAction func didClickClose(_ sender: UIButton) {
        hidden()
    }

    @IBAction func selectBirthday(_ sender: UIButton) {
        let birthday = QFBirthdayController()
        birthday.showDatePick(withMinDate: future)
        
        birthday.pickDateBlock = {[unowned self](date:Date) in
            
            self.dateButton.setTitle(date.stringValue(formatter: "yyyy-MM-dd"), for: .normal)
        }
    }
    
    
    @IBAction func didClickSave(_ sender: UIButton) {
        hidden()
        if callback != nil {
            
            if inputTextfield.text != nil ,inputTextfield.text!.characters.count > 0 {
                
                let number = inputTextfield.text!.replacingOccurrences(of: " ", with: "")
                if future != nil {
                    let date = future!.stringValue(formatter: "yyyy-MM-dd")
                    callback!(date,number)
                }
            }
        }
        
    }
    
    
    func showOpenPlan(){
        
        let window = UIApplication.shared.keyWindow!
        window.addSubview(view)
        window.bringSubview(toFront: view)
        contentView.transformAnimate()
    
    }

}
