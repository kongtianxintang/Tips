/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/16
 * QQ/Tel/Mail:
 * Description:选身高和出生
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFHeightController: UIViewController,UIPickerViewDataSource ,UIPickerViewDelegate{

    var strongSelf:UIViewController?
    
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var pickview: UIPickerView!
    
    var pickHeight:((_ height:Int)->Void)?
    
    private lazy var heights:[Int] = {
        
        var list = Array<Int>()
        
        for i in 140 ... 220 {
            list.append(i)
        }
        return list
        
    }()
    
    convenience init(){
        self.init(nibName:"QFHeightController",bundle: Bundle.main)
        strongSelf = self
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidLayoutSubviews() {
        let bounds = UIScreen.main.bounds
        view.frame = bounds
    }
    //弹框
    func showHeightPick(){
        let window = UIApplication.shared.keyWindow!
        window.addSubview(view)
        window.bringSubview(toFront: view)
        contentView.transformAnimate()
    }
    
    @IBAction func didClickSure(_ sender: Any) {
        strongSelf = nil
        view.removeFromSuperview()
        if pickHeight != nil {
            let index = pickview.selectedRow(inComponent: 0)
            if index >= heights.count || index < 0 {
                return
            }
            let temp = heights[index]
            pickHeight!(temp)
        }
    }
    
    @IBAction func didClickClose(_ sender: Any) {
        strongSelf = nil
        view.removeFromSuperview()
    }
    
    //MARK:uipick的datasource代理方法
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return heights.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let index = heights[row]
        return "\(index)"
    }
    
}
