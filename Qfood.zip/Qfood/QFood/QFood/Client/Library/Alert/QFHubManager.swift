/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/28
 * QQ/Tel/Mail:
 * Description:mbprogresshub管理
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import MBProgressHUD

class QFHubManager: NSObject {
    
    //MARK:展示一个类似安卓的toast
    class func showToast(_ view:UIView?,text:String){
    
        var hub:MBProgressHUD!
        if nil != view {
            hub = MBProgressHUD.showAdded(to: view!, animated: true)
        }else{
            let key = UIApplication.shared.keyWindow!
            hub = MBProgressHUD.showAdded(to: key, animated: true)
        }
        hub.mode = .text
        hub.label.text = text
        hub.hide(animated: true, afterDelay: 2.0)
    }
    
}
