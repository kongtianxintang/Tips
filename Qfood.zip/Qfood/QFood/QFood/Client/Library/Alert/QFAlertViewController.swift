/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/04
 * QQ/Tel/Mail:
 * Description:提示弹框
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFAlertViewController: UIViewController {
    
    var strongSelf:UIViewController?
    @IBOutlet weak var inputTextfield: UITextField!
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var desc: UILabel!
    
    
    var clickBlock:((_ flag:Bool,_ target:String?)->Void)?
    
    convenience init(){
        self.init(nibName:"QFAlertViewController",bundle: Bundle.main)
        strongSelf = self
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        inputTextfield.layer.borderColor = UIColor.textInputBackground.cgColor
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidLayoutSubviews() {
        let bounds = UIScreen.main.bounds
        view.frame = bounds
    }
    
    

    @IBAction func didClickCancel(_ sender: UIButton) {
        strongSelf = nil
        view.removeFromSuperview()
        if clickBlock != nil {
            clickBlock!(false,nil)
        }
    }
    @IBAction func didClickSure(_ sender: UIButton) {
        strongSelf = nil
        view.removeFromSuperview()
        if clickBlock != nil {
            if inputTextfield.text != nil ,inputTextfield.text!.characters.count > 0 {
                clickBlock!(true,inputTextfield.text!)
            }
        }
    }
    
    //弹框
    func showPlan(attributedText:NSAttributedString?){
        let window = UIApplication.shared.keyWindow!
        window.addSubview(view)
        window.bringSubview(toFront: view)
        
        if attributedText != nil {
            desc.attributedText = attributedText
        }
        
        contentView.transformAnimate()
    }
    
    
}

extension UIView {
    
    //contentView的动画
    func transformAnimate(){
        
        //此段代码为抄袭 以后努力。。。
        let previousTransform = self.transform
        layer.transform = CATransform3DMakeScale(0.9, 0.9, 0.0);
        UIView.animate(withDuration: 0.2, animations: {[unowned self] () -> Void in
            self.layer.transform = CATransform3DMakeScale(1.1, 1.1, 0.0);
        }, completion: { [unowned self](Bool) -> Void in
            UIView.animate(withDuration: 0.1, animations: { [unowned self]() -> Void in
                self.layer.transform = CATransform3DMakeScale(0.9, 0.9, 0.0);
            }, completion: {[unowned self] (Bool) -> Void in
                UIView.animate(withDuration: 0.1, animations: {[unowned self] () -> Void in
                    self.layer.transform = CATransform3DMakeScale(1.0, 1.0, 0.0);
                }, completion: { (Bool) -> Void in
                    self.transform = previousTransform
                })
            })
        })
    }

}
