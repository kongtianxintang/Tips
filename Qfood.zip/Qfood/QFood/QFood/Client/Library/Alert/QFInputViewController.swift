/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/18
 * QQ/Tel/Mail:
 * Description:输入框
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFInputViewController: UIViewController {

    var strongSelf:UIViewController?
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var desc: UILabel!//替换描述～～ 腰围尺寸/胸围/臀围
    @IBOutlet weak var input: UITextField!
    
    var callback:((_ input:String)->Void)?
    
    convenience init(){
        self.init(nibName:"QFInputViewController",bundle: Bundle.main)
        strongSelf = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidLayoutSubviews() {
        let bounds = UIScreen.main.bounds
        view.frame = bounds
    }

    //弹框
    func showInputTextfield(){
        let window = UIApplication.shared.keyWindow!
        window.addSubview(view)
        window.bringSubview(toFront: view)
        contentView.transformAnimate()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:保存按钮
    @IBAction func didClickSave(_ sender: Any) {
        hidden()
        if callback != nil {
            if input.text != nil,input.text!.characters.count > 0 {
                callback!(input.text!)
            }
        }
        
    }

    //MARK:关闭按钮
    @IBAction func didClickClose(_ sender: Any) {
        hidden()
    }
    
    private func hidden(){
        strongSelf = nil
        view.removeFromSuperview()
    }
}
