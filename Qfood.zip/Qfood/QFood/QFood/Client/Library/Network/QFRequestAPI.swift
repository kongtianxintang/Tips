/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/28
 * QQ/Tel/Mail:
 * Description:网络请求api
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import Foundation

//主机地址
#if DEBUG
    let QF_HOST_IP = "api.mefood365.com" //测试
#else
    let QF_HOST_IP = "api.mefood365.com" //真实环境
#endif
/* *************************** 注册及登录 ***************************/
//登录接口
let QF_LOGIN = "/user/login"
//注册
let QF_REGISTER = "/user/reg"
//验证码
let QF_SMS = "/user/sms"
//忘记密码
let QF_RESETPWD = "/user/resetpwd"
//更新密码
let QF_UPDATEPWD = "/user/updatePwd"



/* *************************** 首页 ***************************/
//首页数据
let QF_TASK = "/user/task"
//开启方案
let QF_START_PLAN = "/user/start"
//完成任务
let QF_PERFORM_TASK = "/user/performTask"
//获取蓝牙数据
let QF_BODY_DATA = "/user/bodyData"
//添加蓝牙数据
let QF_ADD_BODY_DATA = "/user/bodyDataAdd"



/* *************************** 问答 ***************************/
//食物首页
let QF_FOOD = "/user/food"
//提问
let QF_QUESTIONADD = "/user/questionAdd"
//食物常见列表详情
let QF_DAILY = "/user/isEat"
//搜索食物
let QF_SEARCH_FOOD = "/user/searchFood"
//历史问答
let QF_HISTORY_QUESTION = "/user/question"
//常见问题列表
let QF_SOMATOSENSORY = "/user/faqList"
//常见问题列表详情
let QF_FAQ_DETAILS = "/user/faq"
//常见问题搜索
let QF_SEARCH_FAQ = "/user/searchFaq"
//提问
let QF_ADD_QUESTION = "/user/questionAdd"


/* *************************** 个人页面 ***************************/
//个人页面
let QF_MINE = "/user/my"
//我的方案
let QF_PLAN_INFO = "/user/taskInfo"
//修改个人资料
let QF_EDIT_USER = "/user/editUserInfo"

