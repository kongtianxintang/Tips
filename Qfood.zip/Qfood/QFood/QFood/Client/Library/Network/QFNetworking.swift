/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:网络层
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import Alamofire
import MBProgressHUD
import SwiftyJSON
import CoreData


typealias QFNetworkingFailure = (()->Void)

typealias QFNetworkingSuccess = ((_ json:JSON)->Void)


class QFNetworking: NSObject {
    
    //单例
    static let shared = QFNetworking()
    
    //失败回调
    private var failureblock:QFNetworkingFailure?
    //成功回调
    private var successblock:QFNetworkingSuccess?
    
    //是否正在网络请求
    private lazy var isloading = true
    
//    //get请求 暂时用不到
//    
//    //
//    func get(url:String?,body:Dictionary<String,String>){
//        
//        
//    }
    
    
    //post请求
    final func post(url:String, body:Dictionary<String,Any>,successHandler:QFNetworkingSuccess?=nil,failureHandler:QFNetworkingFailure?=nil){
        
        post(url: url, body: body)
        failureblock = failureHandler
        successblock = successHandler
        
    }
    
    
    private func post(url:String,body:Dictionary<String,Any>){
        
        isloading = true;
        
        let path = "https://" + QF_HOST_IP + url
        
        let keywin = UIApplication.shared.keyWindow!
        
        let hub = MBProgressHUD.showAdded(to: keywin, animated: true)
        hub.label.text = "Loading..."
        
        Alamofire.request(path, method: .post, parameters: body, encoding: JSONEncoding.default, headers: nil).responseData { [unowned hub,unowned self] (responsedata) in
            
            self.isloading = false;
            
            hub.hide(animated: true)
            
            
            if let data = responsedata.result.value {
                let json = JSON.init(data: data)
                //与服务器约定的code非httpcode
                let code = json["code"].intValue
                if code == 200 {
                    if self.successblock != nil{
                        self.successblock!(json["data"])
                    }
                }else{
                    //非200 显示错误描述
                    let desc = json["desc"].string
                    //TODO:code=666的时候用户信息过期
                    if code == 666{
                        self.deleteLoginInfo()
                        let _ = User.contextDelete()
                        QFManagerDisplay().displayLogin()
                    }
                    
                    if self.failureblock != nil{
                        self.failureblock!()
                    }else{
                        
                        let tips = MBProgressHUD.showAdded(to: keywin, animated: true)
                        tips.mode = .text
                        tips.label.text = desc
                        tips.hide(animated: true, afterDelay: 4.0)
                        
                        //最原始的错误信息
                        if desc == nil {
//                            debugPrint("错误信息=\(String.init(data: data, encoding: .utf8))")
                        }
                    }
                }
            }
        }
    }
    
    
    
    //MARK:删除用户登录数据
    private func deleteLoginInfo(){
    
        guard let result = QFDatabase.shared.fetchedResultsController(with: "Login", sortKey: "token") else{
            
            //数据库报错
            assertionFailure("数据库报获取到的result报错")
            return
        }
        
        do {
            try result.performFetch()
            let objs = result.fetchedObjects
            
            if objs != nil, objs!.count > 0 {
                if let context = QFDatabase.shared.createContext() {
                    for item in objs! {
                        context.delete(item as! NSManagedObject)
                    }
                    do {
                        try context.save()
                        QFManagerDisplay().displayLogin()
                    } catch  {
                        assertionFailure("\(error)")
                    }
                }
            }
        } catch let error {
            assertionFailure("\(error)")
        }
    }
    
    
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
    

}
