//
//  QFUpYunManager.swift
//  QFood
//
//  Created by 李伟 on 2017/3/9.
//  Copyright © 2017年 QFood. All rights reserved.
//

import UIKit
import MBProgressHUD
import SwiftyJSON

//坑爹 ！只有一个weight空间 其他是路径
enum QFBucktNameType{

    case Weight
    case Avatar
    case FoodTaskPic
    case PhysicalPic
    case BodyPic
    case QuestionPic
    
    var bucktName:String {
        switch self {
        case .Weight:
            return "weight"
        case .Avatar:
            return "avatar"
        case .FoodTaskPic :
            return "foodTaskPic"
        case .PhysicalPic:
            return "physicalPic"
        case .QuestionPic:
            return "questionPic"
        default:
            return "bodyPic"
        }
    }
}
typealias QFUpLoaderSuccessBlock = ((_ path:String)->Void)
typealias QFMultiUpLoaderSuccessBlock = ((_ path:String)->Void)
class QFUpYunManager: NSObject {
    
    private lazy var operat = "liwei"
    private lazy var pasword = "liwei!@#$"
    
    private lazy var upyunInstance = UpYunFormUploader()
    
    private lazy var upYunBlockInstance = UpYunBlockUpLoader()
    
    private var picPath:String?
    
    private lazy var lock:NSLock = NSLock()
    
    func uploader(bucketType:QFBucktNameType,fileData:Data,successblock:QFUpLoaderSuccessBlock?){
    
        let keywindow = UIApplication.shared.keyWindow!
        var hub:MBProgressHUD!
        DispatchQueue.main.async {
           hub = MBProgressHUD.showAdded(to: keywindow, animated: true)
        }
        
            //保存路径
            let date = Date()
            let time = Int (date.timeIntervalSince1970)
            let arc = arc4random() % 100
            let savekey = "/\(bucketType.bucktName)/\(time)" + "\(arc)" + ".jpg"
        
        
        upyunInstance.upload(withBucketName: QFBucktNameType.Weight.bucktName, operator: operat, password: pasword, fileData: fileData, fileName: bucketType.bucktName, saveKey: savekey, otherParameters: ["valuew":"key"], success: { (response:HTTPURLResponse?,json: [AnyHashable : Any]?) in
            
            do {
                
                let data = try JSONSerialization.data(withJSONObject: json!, options: JSONSerialization.WritingOptions.init(rawValue: 0))
                let swiftjson = JSON.init(data: data)
                self.lock.lock()
                if self.picPath != nil{
                
                    self.picPath! += "," + swiftjson["url"].stringValue
                }else{
                    self.picPath = swiftjson["url"].stringValue
                }
                
                self.lock.unlock()
                
                if successblock != nil && self.picPath != nil{
                    successblock!(self.picPath!)
                }
                
                }catch{
                assertionFailure("json转换成data不成功\(error)")
            
            }
            defer{
            
                DispatchQueue.main.async {
                    hub.mode = .determinate
                    hub.removeFromSuperViewOnHide = true
                    hub.hide(animated: true)
                }
            }
        }, failure: { (error:Error?, response:HTTPURLResponse?, hash:[AnyHashable : Any]?) in
            DispatchQueue.main.async {
                hub.mode = .determinate
                hub.removeFromSuperViewOnHide = true
                hub.hide(animated: true)
                
                QFHubManager.showToast(nil, text: "上传失败")
            }
            
        }) { (start:Int64, total:Int64) in
            DispatchQueue.main.async {
//                hub.progress = Float(Float(start) / Float(total))
            }
        }

    }
    
    //多张上传
    func uploaderMulti(datas:[Data],bucketType:QFBucktNameType,successblock:QFMultiUpLoaderSuccessBlock?){
    
        let group = DispatchGroup()
        let queue = DispatchQueue.init(label: "com.wanguohui.ios")
        for i in 0 ..< datas.count {
            let item = datas[i]
            let workitem = DispatchWorkItem.init(block: { 
                self.uploader(bucketType: bucketType, fileData: item, successblock: { (path:String) in
                    
                        if successblock != nil && self.picPath != nil{
                            let temps = self.picPath!.components(separatedBy: ",")
                            if temps.count == datas.count{
                                successblock!(self.picPath!)
                            }
                        }
                })
            })
            queue.async(group: group, execute: workitem)
        }
//        group.wait()
    }
   
}
