/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:登录页
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON
import CoreData
import MBProgressHUD

class QFLoginViewController: QFBaseViewController {

    @IBOutlet weak var telephone: UIView!
    @IBOutlet weak var password: UIView!
    
    @IBOutlet weak var telephoneTextField: UITextField!
    @IBOutlet weak var pwTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "登录"

        telephone.layer.borderColor = UIColor.textInputBackground.cgColor
        password.layer.borderColor = UIColor.textInputBackground.cgColor
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBOutlet weak var didClickLogin: UIButton!
    
    
    //登录
    @IBAction func didClickLogin(_ sender: UIButton) {
        
        
        if checkTelephone() && checkpassword() {
        
        let body = ["mobile":telephoneTextField.text!,"password":pwTextField.text!]
        
        QFNetworking.shared.post(url: QF_LOGIN, body: body, successHandler: { (json:JSON) in
            
            //切换rootviewcontroller
            QFManagerDisplay().loginOrRegisterSuccess()
            //获取到用户数据并保存到本地
            if let context = QFDatabase.shared.createContext(){
                
                let entity = NSEntityDescription.insertNewObject(forEntityName: "Login", into: context)
                entity.setValue(json["token"].stringValue, forKey: "token")
                entity.setValue(json["user_id"].stringValue, forKey: "user_id")
                entity.setValue(json["task_logId"].int64Value, forKey: "task_logId")
                do{
                    try context.save()
                    }catch let error{
                    assertionFailure("保存失败\(error)")
                }
            }
            
            }, failureHandler: nil)
            
        }
    }

    //注册
    @IBAction func didClickRegister(_ sender: UIButton) {
        let register = QFRegisterViewController()
        show(register, sender: nil)
        
//        let guide = QFGuideViewController()
//        show(guide, sender: nil)
        
        //TEST:特别说明
//        let explian = QFExplainViewController()
//        show(explian, sender: nil)
//        let report = QFReportController()
//        show(report, sender: nil)
        
        
//        let input = QFInputViewController()
//        input.showInputTextfield()
//        input.callback = {(input:String) in
//        
//            debugPrint("callback:\(input)")
//        
//        }
        
//        testTFScale()
        
    }
    
    //忘记密码
    @IBAction func didClickForgetPassword(_ sender: UIButton) {
        let forget = QFRegisterViewController.init(type: .forgetPW)
        show(forget, sender: nil)
//        testScale()
    }
   
    private func checkpassword()->Bool{
    
        guard let pw = pwTextField.text else {
            return false
        }
        
        if pw.characters.count <= 0 {
            return false
        }
        
        return true
    }
    
    private func checkTelephone()->Bool{
    
        guard let tele = telephoneTextField.text else {
            let hub = MBProgressHUD.showAdded(to: view, animated: true)
            hub.mode = .text
            hub.label.text = "请输入手机号"
            hub.hide(animated: true, afterDelay: 1.0)
            return false
        }
        
        let isvaild = LWRegular.phoneNum(tele).isRight
        
        if !isvaild {
            let hub = MBProgressHUD.showAdded(to: view, animated: true)
            hub.mode = .text
            hub.label.text = "无效的手机号"
            hub.hide(animated: true, afterDelay: 1.0)
            return false
        }
        
        return true
    }
    
}
