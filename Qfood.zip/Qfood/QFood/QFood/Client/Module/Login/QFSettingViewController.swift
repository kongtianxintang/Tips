/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:设置页
 * Others:fix:collectionview cell之间 有1px问题
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
//import Speech ~~siri框架
import SwiftyJSON

class QFSettingViewController: QFBaseViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource{

    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var headerIcon: UIImageView!
    @IBOutlet weak var nikeName: UILabel!
    @IBOutlet weak var target: UILabel!
    @IBOutlet weak var userBorn: UILabel!
    @IBOutlet weak var genderIcon: UIImageView!
    
    private var flow:UICollectionViewFlowLayout?
    
    private let settingTableviewCellID = "setting_tableview_cell"
    private let settingCollectiviewCellID = "setting_collectionview_cell"
    
    private lazy var tableDatasource:[(name:String,classname:String)] = [("我的设备","QFMyDeviceViewController"),("账号管理","QFAccountViewController"),("系统设置","QFSystemTableViewController")]
    
    private lazy var collectionvDatasource:[(name:String,classname:String,icon:String)] = [("我的方案","QFMyPlanController","scheme"),("身体数据","QFBodyDataController","body_data")]
    //,("身体数据","QFMyPlanController","body_data")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configTableview()
        
        configCollectionview()
        
        defaultData()
        
        fetachData()
    }

    
    //MARK:默认取值
    private func defaultData(){
    
        //如果有数据则展示默认
        if let user = User.contextFetchUser() {
            
            //头像
            if let header = user.user_avatar {
                headerIcon.qfSet(with: header, completionHandler: nil)
            }
            //名字
            nikeName.text = user.user_nikname
            
            //性别 1=男 2=女
            let iconname = user.sex == 1 ? "maleIcon":"femaleIcon"
            genderIcon.image = UIImage.init(named: iconname)
            
            //s年代
            if let birthday = user.birthday{
                let split = birthday.components(separatedBy: "-")
                if split.count >= 2 {
                    let bron = Int.init(split[1])
                    if bron != nil {
                        let s = user.s
                        if s != nil {
                            let bronstr = s! + "后," + "\(bron!)月 生人"
                            userBorn.text = bronstr
                        }
                    }
                }
            }
            
            //目标体重
            let goal = user.target_weight
            target.text = "目标减\(goal)公斤"
        }
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //TODO #collectionview 布局 cell间有1px的间隔
    //config tableview
    private func configTableview(){
        //register cell
        tableview.register(UINib.init(nibName: "QFSettingTableViewCell", bundle: nil), forCellReuseIdentifier: settingTableviewCellID)
        tableview.estimatedRowHeight = 44
        
    }
    
    
    //config collectionview
    private func configCollectionview(){
        //register
        collectionview.register(UINib.init(nibName: "QFSettingCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: settingCollectiviewCellID)
    
    }
    override func viewDidLayoutSubviews() {
        
        //set flowlayout
        if flow == nil {
            flow = UICollectionViewFlowLayout.init()
            flow!.scrollDirection = .horizontal
            flow!.minimumLineSpacing = 0
            flow!.minimumInteritemSpacing = 0
            let size = collectionview.frame.size
            let width = size.width / CGFloat(collectionvDatasource.count)
            let height = size.height
            flow!.itemSize = CGSize.init(width: width, height: height)
            collectionview.collectionViewLayout = flow!
//            debugPrint("bounds.size =\(collectionview.bounds.size)")
            addShaperLayer()
        }
    }
    
    //headericon add layer
    private func addShaperLayer(){
    
        
        let size = headerIcon.bounds.size
        let height = size.height
        let path = UIBezierPath.init(roundedRect: headerIcon.bounds, cornerRadius: height / 2.0 - 5.0)
        headerIcon.layer.cornerRadius = height / 2.0
        let shape = CAShapeLayer()
        shape.fillColor = UIColor.clear.cgColor
        shape.path = path.cgPath
        shape.lineWidth = 5.0
        shape.strokeColor = UIColor.QFlightCellBackground.cgColor
        shape.opacity = 0.8
        headerIcon.layer.addSublayer(shape)
    
    }
    
    //#uitableview的ui和source代理协议
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableDatasource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: settingTableviewCellID, for: indexPath) as! QFSettingTableViewCell
        let info = tableDatasource[indexPath.row]
        cell.desc.text = info.name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let info = tableDatasource[indexPath.row]
        let classStr = "QFood." + info.classname
        guard let aClass = NSClassFromString(classStr) else { return }
        let t  = aClass as! UIViewController.Type
        let controller = t.init()
        show(controller, sender: nil)
        
    }
    
    
    //#uicollectionview的ui和source代理协议
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionvDatasource.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: settingCollectiviewCellID, for: indexPath) as! QFSettingCollectionViewCell
        let info = collectionvDatasource[indexPath.row]
        cell.desc.text = info.name
        cell.icon.image = UIImage.init(named: info.icon)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let info  = collectionvDatasource[indexPath.row]
        let classStr = "QFood." + info.classname
        guard let aClass = NSClassFromString(classStr) else { return }
        let t  = aClass as! UIViewController.Type
        let controller = t.init()
        show(controller, sender: nil)
    }
    
    
    @IBAction func didClickModifyUserInfo(_ sender: UIButton) {
        let info = QFMotifyInfoController()
        info.motifyBlock = {[unowned self] in
            self.fetachData()
        }
        show(info, sender: nil)
        
    }

    
    //获取数据
    func fetachData(){
        
        if let login = Login.fetchLogin() {
            
            let body = ["token":login.token!,"task_logId":login.task_logId,"user_id":login.user_id!] as [String : Any]
            QFNetworking.shared.post(url: QF_MINE, body: body, successHandler: {[unowned self](json) in
    
                self.configUIwithjson(json: json)
                
            }, failureHandler: nil)
            
        }
    }
    
    func configUIwithjson(json:JSON){
    
        //头像
        let header = json["user_avatar"].stringValue
        headerIcon.qfSet(with: header, completionHandler: nil)
        
        //名字
        nikeName.text = json["user_nikname"].stringValue
        
        //性别 1=男 2=女
        let iconname = json["sex"].int8Value == 1 ? "maleIcon":"femaleIcon"
        genderIcon.image = UIImage.init(named: iconname)
        
        //s年代
        let birthday = json["birthday"].stringValue
        let split = birthday.components(separatedBy: "-")
        if split.count >= 2 {
            let bron = Int.init(split[1])
            if bron != nil {
                let s = json["s"].stringValue
                let bronstr = s + "后," + "\(bron!)月 生人"
                userBorn.text = bronstr
            }
        }
        
        //目标体重
        let goal = json["target_weight"].int8Value
        target.text = "目标\(goal)公斤"
        
        //TODO:以后修改coredata更新
        //删除旧的数据
        let _ = User.contextDelete()
        //保存新的数据
        let _ = User.contextSave(json: json)
        
    }
    
}
