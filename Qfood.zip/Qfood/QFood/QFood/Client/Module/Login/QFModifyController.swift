/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/01
 * QQ/Tel/Mail:
 * Description:修改密码～·看错 😄
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import MBProgressHUD

class QFModifyController: QFBaseViewController {
    @IBOutlet weak var oldBackview: UIView!
    @IBOutlet weak var newBackview: UIView!
    @IBOutlet weak var checkBackview: UIView!

    @IBOutlet weak var oldPWTextfield: UITextField!
    @IBOutlet weak var newPWTextfield: UITextField!
    @IBOutlet weak var checkPWTextfield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "修改密码"
        
        oldBackview.layer.borderColor = UIColor.textInputBackground.cgColor
        newBackview.layer.borderColor = UIColor.textInputBackground.cgColor
        checkBackview.layer.borderColor = UIColor.textInputBackground.cgColor
        
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func didClickSave(_ sender: UIButton) {
        //TODO:修改密码
        let key = UIApplication.shared.keyWindow!
        
        
        guard let old = oldPWTextfield.text else {
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "旧密码不能为空"
            hub.hide(animated: true, afterDelay: 2.0)
            return
        }
        guard let new = newPWTextfield.text else {
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "新密码不能为空"
            hub.hide(animated: true, afterDelay: 2.0)
            return
        }
        
        guard let check = checkPWTextfield.text else {
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "确认密码不能为空"
            hub.hide(animated: true, afterDelay: 2.0)
            return
        }
        
        guard new == check else {
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "新密码与确认密码不相同"
            hub.hide(animated: true, afterDelay: 2.0)
            return
        }
        
        
        guard let login = Login.fetchLogin()else {
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "你还没登录"
            hub.hide(animated: true, afterDelay: 2.0)
            return
        }
        
        let body = ["token":login.token!,"user_id":login.user_id!,"password":old,"newpassword":new]
        
        QFNetworking.shared.post(url: QF_UPDATEPWD, body: body, successHandler: {[unowned self] (json) in
            let _ = self.navigationController?.popViewController(animated: true)
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "修改成功"
            hub.hide(animated: true, afterDelay: 2.0)
//            debugPrint("修改成功毁掉=\(json)")
        })
        
    }
    
    

}
