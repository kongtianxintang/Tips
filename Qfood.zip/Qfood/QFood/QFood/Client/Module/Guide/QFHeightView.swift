/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:指导页 ～～ 选择身高
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFHeightView: UIView,UIPickerViewDelegate,UIPickerViewDataSource{
    
    
    lazy var heights:[Int] = {
    
        var list = Array<Int>()
        
        for i in 140 ... 220 {
            list.append(i)
        }
        return list
    
    }()
    
    @IBOutlet weak var pickview: UIPickerView!

//    func getHeight:Int
    
    override func awakeFromNib() {
        pickview.delegate = self
        pickview.dataSource = self
        pickview.selectRow(30, inComponent: 0, animated: true)
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return heights.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return "\(heights[row])"
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
}
