/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:指导页～选择男女
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/
import UIKit

class QFSelectGender: UIView {

    var clickBlock:((_ isMan:Bool)->Void)?
    
    @IBOutlet weak var manButton: UIButton!
    @IBOutlet weak var womanButton: UIButton!
    
    @IBOutlet weak var manLabel: UILabel!
    @IBOutlet weak var womanLabel: UILabel!
    
    private lazy var imgs = [(select:"man_select",normal:"man"),(select:"woman",normal:"woman_normal")]
    
    override func awakeFromNib() {
        womanLabel.textColor = UIColor.init(hexString: "#d4237a")
    }

    //
    @IBAction func didClickMan(_ sender: UIButton) {
        //
        sender.setBackgroundImage(UIImage.init(named: imgs[0].select), for: .normal)
        womanButton.setBackgroundImage(UIImage.init(named: imgs[1].normal), for: .normal)
        manLabel.textColor = UIColor.init(hexString: "#86BB16")
        womanLabel.textColor = UIColor.init(hexString: "#bfbfbf")
        if clickBlock != nil {
            clickBlock!(true)
        }
    }
    
    @IBAction func didClickWoman(_ sender: UIButton) {
        //
        sender.setBackgroundImage(UIImage.init(named: imgs[1].select), for: .normal)
        manButton.setBackgroundImage(UIImage.init(named: imgs[0].normal), for: .normal)
        manLabel.textColor = UIColor.init(hexString: "#bfbfbf")
        womanLabel.textColor = UIColor.init(hexString: "#d4237a")
        if clickBlock != nil{
            clickBlock!(false)
        }
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
}
