/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:指导页
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import TZImagePickerController
import MBProgressHUD
import SwiftyJSON



class QFGuideViewController: QFBaseViewController,UIScrollViewDelegate,TZImagePickerControllerDelegate,CBCentralManagerDelegate{

    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var nextStep: UIButton!
    @IBOutlet weak var scrollview: UIScrollView!
    
    private lazy var upYunManager = QFUpYunManager()
    private lazy var body = Dictionary<String,Any>()
    
    private var currentIndex:Int = 0 {
        
        didSet{
            if currentIndex < descriptions.count {
                pageControl.currentPage = currentIndex
                let width = scrollview.bounds.width
                let point = CGPoint.init(x: CGFloat(currentIndex) * width, y: 0)
                scrollview.contentOffset = point
                let desc = descriptions[currentIndex]
                descLabel.text = desc
            }
        }
    
    };
    
    private lazy var gender = Bundle.main.loadNibNamed("QFSelectGender", owner: nil, options: nil)!.last as! QFSelectGender
    
    private lazy var nickname = Bundle.main.loadNibNamed("QFNickname", owner: nil, options: nil)!.last as! QFNickname
    
    private lazy var heightview = Bundle.main.loadNibNamed("QFHeightView", owner: nil, options: nil)!.last as! QFHeightView
    
    private lazy var bornview = Bundle.main.loadNibNamed("QFBornView", owner: nil, options: nil)!.last as! QFBornView
    
    private lazy var syncInfoview = Bundle.main.loadNibNamed("QFSyncInfoView", owner: nil, options: nil)!.last as! QFSyncInfoView
    
    private var viewlist:[UIView]?
    
    private lazy var descriptions = ["请选择性别","请输入昵称上传头像","请选择身高","请选择出生年月","请开启蓝牙,连接到体脂秤"]
    
    private var manager:CBCentralManager?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        title = "Nutribody"
        
        createRightBarItem()
        
        DispatchQueue.main.async {[unowned self] in
            self.viewlist = [self.gender,self.nickname,self.heightview,self.bornview,self.syncInfoview]
            
            self.scrollview.isPagingEnabled = true
            
            self.pageControl.numberOfPages = self.viewlist!.count
            
            for item in self.viewlist! {
                self.scrollview.addSubview(item)
            }
            
        }
        
        //TODO:判断是开启了蓝牙 如果开启了 继续走 如果未开启则提示去开启
        manager = CBCentralManager.init(delegate: self, queue: nil)
        
        
        //头像
        nickname.clickBlock = {[unowned self] (button:UIButton)->Void  in
            
            let pick = TZImagePickerController.init(maxImagesCount: 1, delegate: self)
            pick!.maxImagesCount = 1
            pick!.didFinishPickingPhotosHandle = {( imgs:[UIImage]?, _: [Any]?, Bool)->Void in
            
                if imgs != nil , imgs!.count > 0 {
                    button.setBackgroundImage(imgs![0], for: UIControlState.normal)
                    if let data = UIImageJPEGRepresentation(imgs![0], 0.5) {
                        self.upYunManager.uploader(bucketType: .Avatar, fileData: data, successblock: { (path:String) in
                            let _ = self.body.updateValue(path, forKey: "user_avatar")
                        })
                    }
                }
            }
            self.present(pick!, animated: true, completion: nil)
        }
        
        
        //性别
        gender.clickBlock = {[unowned self ](flag:Bool) in
        
            let sex = flag ? "1":"2"
            
            let _ = self.body.updateValue(sex, forKey: "sex")
        
        }
        
        
        //链接秤 同步信息
        syncInfoview.syncCallback = { [unowned self] (sender:UIButton)  in
        
            if nil != self.manager {
                switch self.manager!.state {
                case .poweredOff:
                    self.bluetoothPoweredOffAction()
                default:
                    self.uploadUerinfo()
                    break;
                }
            }
        }
    }

    override func viewDidLayoutSubviews() {
        let size = scrollview.bounds.size
        let width = size.width
        
        if viewlist != nil {
            scrollview.contentSize = CGSize.init(width:CGFloat(viewlist!.count) * width, height: scrollview.bounds.height)
            for item in 0 ..< viewlist!.count {
                let rect = CGRect.init(origin: CGPoint.init(x: CGFloat(item) * width, y: 0), size: size)
                let tempview = viewlist![item]
                tempview.frame = rect
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let offset = scrollView.contentOffset
        let x = offset.x
        let width = scrollView.bounds.width
        
        let index = x / width
        
        currentIndex = Int(index)
        
    }
    
    
    
    @IBAction func didClickBack(_ sender: UIButton) {
        
        if currentIndex >= 1 {
            
            currentIndex -= 1
            
        }
        
    }
    
    @IBAction func didClickNextStep(_ sender: UIButton) {
        
        if currentIndex < viewlist!.count - 1{
            
            //昵称模块
            if currentIndex == 1 {
                if nickname.nicknameTextfield.text != nil,nickname.nicknameTextfield.text!.characters.count > 0 {
                    let name = nickname.nicknameTextfield.text!
                    let _  = body.updateValue(name, forKey: "user_nikname")
                }else{
                    let hub = MBProgressHUD.showAdded(to: view, animated: true)
                    hub.mode = .text
                    hub.label.text = "请输入昵称"
                    hub.hide(animated: true, afterDelay: 2.0)
                    return
                }
            }
            //选择生日模块
            if currentIndex == 3 {
            
                let date = bornview.datepicker.date
                let _ = body.updateValue(date.stringValue(formatter: "yyyy-MM"), forKey: "birthday")
            }
            
            if currentIndex == 2{
            
                let index = heightview.pickview.selectedRow(inComponent: 0)
                var height = 170
                if index > -1 && index < heightview.heights.count {
                    height = heightview.heights[index]
                }
                let _ = body.updateValue(height, forKey: "height")
                
            }
            currentIndex += 1
            
        }
        
    }
    
    private func uploadUerinfo(){
    
        guard let login = Login.fetchLogin() else {
            assertionFailure("登录信息为空")
            return
        }
        let _ = body.updateValue(login.token!, forKey: "token")
        let _ = body.updateValue(login.user_id!, forKey: "user_id")
        
        QFNetworking.shared.post(url: QF_EDIT_USER, body: body, successHandler: { [unowned self](json:JSON) in
            
            self.syncTFScaleInfo()
            
            }, failureHandler: nil)
    
    }
    
    private func showOpenPlan(result:TFScaleResult){
    
        //TODO:逻辑～什么时候开启
        let alert = QFAlertViewController()
        
        //TODO:从蓝牙获取数据
        
        let normal = [NSForegroundColorAttributeName:UIColor.lightGray,NSFontAttributeName:UIFont.systemFont(ofSize: 15)]
        
        let number = [NSForegroundColorAttributeName:UIColor.gray,NSFontAttributeName:UIFont.systemFont(ofSize: 17)]
        
        let kg = [NSFontAttributeName:UIFont.systemFont(ofSize: 15),NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground]
        
        let current = NSMutableAttributedString.init(string: "您的当前体重:", attributes: normal)
        current.append(NSAttributedString.init(string: " \(result.weight) ", attributes: number))
        current.append(NSAttributedString.init(string: "KG\n", attributes: kg))

        
        let standard = NSMutableAttributedString.init(string: "您的标准体重:",attributes:normal)
        standard.append(NSAttributedString.init(string: " \(result.sw) ", attributes: number))
        standard.append(NSAttributedString.init(string: "KG", attributes: kg))
        
        current.append(standard)
        
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineSpacing = 5.0
        paragraph.alignment = .center
        
        current.addAttributes([NSParagraphStyleAttributeName:paragraph], range: NSRange.init(location: 0, length: current.length))
        
        alert.showPlan(attributedText: current)
        
        //true 开启方案 flase 不开启方案
        alert.clickBlock = { [unowned self] (flag:Bool,target:String?) in
        
            if flag {
                
                let json = ["Weight":result.weight,"muscle":result.muscleWeight,"Calorie":0,"VisceralFat":result.visceralFatPercentage,"Bone":result.boneWeight,"bmi":result.bmi,"water":result.waterWeight]
                
                let report = QFReportController()
                report.json = json
                report.targetWeight = target
                self.show(report, sender: nil)
                
            }else{
            
                QFManagerDisplay().loginOrRegisterSuccess()
            }
        
        }
    
    }
    
    
    func syncTFScaleInfo(){
        
        syncInfoview.contentView.isHidden = false
        syncInfoview.syncButton.isHidden = true
        
        //年龄
        let date = bornview.datepicker.date
        let old = Calendar.current.component(.year, from: date)
        let new = Calendar.current.component(.year, from: Date())
        let age = new - old
        
        var gender:Bool = false
        
        let sex = body["sex"] as? String
        
        if nil != sex {
            gender = sex! == "1" ? true:false
        }
        
        TFScaleManager.scanDevice(withTimeut: 10.0, deviceTypeOptions: TFDeviceType.all, findDevice: nil)
        
        let index = heightview.pickview.selectedRow(inComponent: 0)
        
        var height = 170
        if index > -1 && index < heightview.heights.count {
            height = heightview.heights[index]
        }
        
        
        TFScaleManager.startScale(withAge: UInt(age), gender: gender, height: UInt(height), deviceTypeOptions: TFDeviceType.all, timeOut: 10.0) { [unowned self](result:TFScaleResult?, error:Error?) in
            
            if nil != error{
            
//                debugPrint("错误error=\(error!) result=\(result) ")
                self.syncInfoview.contentView.isHidden = true
                self.syncInfoview.syncButton.isHidden = false
                self.syncInfoview.syncButton.setTitle("同步失败,请重试", for: .normal)
                
            }else{
                if nil != result {
                    self.showOpenPlan(result: result!)
                }
            }
        }
    
    }
    
    //MARK:CBCentralManagerDelegate的代理方法
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOff:
            bluetoothPoweredOffAction()
        default:
            break;
        }
    }

    //用户蓝牙关闭操作
    private func bluetoothPoweredOffAction(){
    
        let alert = UIAlertController()
        let cancel = UIAlertAction.init(title: "取消", style: UIAlertActionStyle.cancel, handler: nil)
        let sure = UIAlertAction.init(title: "去开启蓝牙", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
            //MARK:去开启蓝牙
            let url = URL.init(string: "App-Prefs:root=Bluetooth")
            if nil != url {
                if UIApplication.shared.canOpenURL(url!){
                    UIApplication.shared.openURL(url!)
                }
            }
        }
        alert.addAction(cancel)
        alert.addAction(sure)
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    //MARK:右上角跳过button
    private func createRightBarItem(){
        let right = UIBarButtonItem.init(title: "跳过", style: UIBarButtonItemStyle.done, target: self, action:#selector(rightBarItemAction(item:)))
        navigationItem.rightBarButtonItem = right
    }
    func rightBarItemAction(item : UIBarButtonItem){
        
        QFManagerDisplay().loginOrRegisterSuccess()
    }
    
    
}
