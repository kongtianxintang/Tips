/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:调查表
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFReportController: UITableViewController {

    private let  list = ["你是否患有高血压?","你是否患有糖尿病?","你是否尿酸高?","你是否患有痛风?","您是否大豆过敏?","您是否牛奶过敏?"]
    private lazy var disease = ["高血压","糖尿病","尿酸","痛风","大豆过敏","牛奶过敏"]
    private let reuseID = "QFReportCell"
    private lazy var health = Dictionary<String,String>()
    private lazy var d = NSMutableDictionary()
    var json:[String:Any]?
    var targetWeight:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "健康调查"
        
        configTableviewFooterAndHeader()
        
        tableView.register(UINib.init(nibName: "QFReportCell", bundle: Bundle.main), forCellReuseIdentifier: reuseID)
        tableView.separatorStyle = .none
        
    }

    
    private func configTableviewFooterAndHeader(){
        
        
        let label = UILabel()
        label.textAlignment = .center
        label.textColor = UIColor.textInputBackground
        label.text = "请如实填写您的健康情况"
        label.frame.size.height = 44
        tableView.tableHeaderView = label
        tableView.sectionHeaderHeight = 0
        tableView.sectionFooterHeight = 0
    
        let footer = Bundle.main.loadNibNamed("QFExplainFooterView", owner: nil, options: nil)!.last as! QFExplainFooterView
        tableView.tableFooterView = footer
        footer.frame.size.height = 120
        footer.descLabel.isHidden = true
        footer.submitBlock = {[unowned self] _ in
            
            //TODO:逻辑
            let keys = self.health.keys
            var helthStr:String?
            for item in keys {
                let value = self.health[item]
                if helthStr != nil {
                    helthStr! += ( "," + value!)
                }else{
                    helthStr = value
                }
            }
            //TODO:可能为空
//            debugPrint("健康格式=\(helthStr)")
            let explain  = QFExplainViewController()
            explain.json = self.json
            explain.health = helthStr
            explain.targetWeight = self.targetWeight
            self.show(explain, sender: nil)
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return list.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseID, for: indexPath) as! QFReportCell
        let index = indexPath.row + 1
        let isdrak = index % 2 == 1 ? true : false
        cell.contentview.backgroundColor = isdrak ? UIColor.textInputBackground : UIColor.QFlightCellBackground
        cell.desc.text = list[indexPath.row]
        cell.clickBlock = {[unowned self](flag:Bool)->Void in
            
            //MARK:是就添加 否就移除
            if flag {
                let _ = self.health.updateValue(self.disease[indexPath.row], forKey: "\(indexPath.row)")
            }else{
                let _ = self.health.removeValue(forKey: "\(indexPath.row)")
            }
            
        }
        return cell
        
    }
    
}
