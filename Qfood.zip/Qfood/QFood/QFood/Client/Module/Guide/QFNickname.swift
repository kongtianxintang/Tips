/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:指导页 ~~~~ 上传头像和昵称
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFNickname: UIView {

    var clickBlock:(( _ sender:UIButton)->Void)?
    
    
    @IBOutlet weak var nicknameTextfield: UITextField!

    @IBAction func didClickUploadHeaderIcon(_ sender: UIButton) {
        
        if clickBlock != nil {
            clickBlock!(sender)
        }
        
    }
    override func awakeFromNib() {
        nicknameTextfield.layer.borderColor = UIColor.textInputBackground.cgColor
        nicknameTextfield.layer.borderWidth = 0.5
        nicknameTextfield.layer.cornerRadius = 2.0
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
}
