/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:指导页 ～～ 出生日期
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/
import UIKit

class QFBornView: UIView {

    @IBOutlet weak var datepicker: UIDatePicker!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    override func awakeFromNib() {
        datepicker.maximumDate = Date()
    }
    
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
}
