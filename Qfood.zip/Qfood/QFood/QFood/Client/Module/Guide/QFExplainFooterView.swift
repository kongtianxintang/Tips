/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:特别说明footerview
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFExplainFooterView: UIView {


    
    var submitBlock:(()->Void)?
    
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var submitButton: UIButton!
    
    override func awakeFromNib() {
        
    }
    
    
    @IBAction func didClickSubmit(_ sender: Any) {
        
        if submitBlock != nil {
            submitBlock!()
        }
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
    
}
