//
//  QFReportCell.swift
//  QFood
//
//  Created by 李伟 on 2017/3/4.
//  Copyright © 2017年 QFood. All rights reserved.
//

import UIKit

class QFReportCell: UITableViewCell,QFCheckBoxDelegate{

    @IBOutlet weak var checkbox: QFCheckBox!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var contentview: UIView!
    
    
    /// flag : true - 是        false - 否
    var clickBlock:((_ flag:Bool)->Void)?
    
    private  lazy var checks:[(radio:String,normal:String,name:String)] = [("checkbox-radio","checkbox-normal","是"),("checkbox-radio","checkbox-normal","否")]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        checkbox.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func numberOfSections() -> Int {
        return 1
    }
    
    func checkbox(numberOfItemsInSection section: Int) -> Int {
        return checks.count
    }
    
    func checkbox(checkbox: QFCheckBox, cellForItem indexPath: IndexPath) -> UICollectionViewCell {
        let cell = checkbox.dequeueReusablecell(cellForItemAt: indexPath) as! QFCheckBoxCell
        let info = checks[indexPath.row]
        cell.icon.image = UIImage.init(named: info.normal)
        cell.dec.text = info.name
        return cell
    }
    
    func checkbox(checkbox: QFCheckBox, didSelectItemAt indexPath: IndexPath) {
        let cell = checkbox.cellForItem(at: indexPath) as? QFCheckBoxCell
        if cell != nil {
            let info = checks[indexPath.row]
            cell!.icon.image = UIImage.init(named: info.radio)
            if clickBlock != nil {
                if indexPath.row == 0 {
                    clickBlock!(true)
                }else{
                    clickBlock!(false)
                }
            }
        }
    }
    
    func checkbox(checkbox: QFCheckBox, didDeselectItemAt indexPath: IndexPath) {
        let cell = checkbox.cellForItem(at: indexPath) as? QFCheckBoxCell
        if cell != nil {
            let info = checks[indexPath.row]
            cell!.icon.image = UIImage.init(named: info.normal)
        }
    }
    
}
