/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:指导页 ～～ 同步信息 秤
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFSyncInfoView: UIView {

    
    @IBOutlet weak var loading: UIImageView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var syncButton: UIButton!
    
    
    var syncCallback:((_ sender:UIButton)->Void)?
    
//    override func awakeFromNib() {
//
//        loadingAnimation()
//    }
    
    @IBAction func didClickSyncInfo(_ sender: UIButton) {
        loading.rotationAnimation()
        if syncCallback != nil {
            syncCallback!(sender)
        }
    }
    
}
