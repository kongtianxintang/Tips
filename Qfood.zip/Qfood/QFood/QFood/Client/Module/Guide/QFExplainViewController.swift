/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/03
 * QQ/Tel/Mail:
 * Description:特别说明
 * Others:fix:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFExplainViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var tableview: UITableView!
    var json:[String:Any]?
    var health:String?
    var targetWeight:String?
    private let reuseID = "cell"
    
    private let descs = ["1.严重的肝肾疾病","2.充血性心力衰竭患者","3.心脏病发作6个月内","4.双极型精神障碍患者(正在接受锂治疗)","5.帕金森氏症患者","6.老年痴呆症患者","7.严格的素食主义者","8.癌症患者","9.孕妇和哺乳期妇女"];
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: reuseID)
        
        
        descLabel.text = "特别说明:有以下情况之一者\n均不可采用Nutribody体重管理方案"
        
        title = "特别说明"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return descs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseID, for: indexPath)
        cell.selectionStyle = .none
        cell.textLabel?.text = descs[indexPath.row]
        cell.textLabel?.numberOfLines = 0
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 58.0
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footer = Bundle.main.loadNibNamed("QFExplainFooterView", owner: nil, options: nil)!.last as! QFExplainFooterView
        tableview.tableFooterView = footer
        
        
        let att = NSMutableAttributedString.init(string: "我已阅读 ", attributes: nil)
        
        let m = NSAttributedString.init(string: "免责声明", attributes: [NSForegroundColorAttributeName:UIColor.green])
        att.append(m)
        
        
        footer.descLabel.attributedText = att
        
        footer.submitBlock = {[unowned self]()->Void  in
            
            let open = QFOpenPlanController()
            open.showOpenPlan()
            
            open.callback = {[unowned self](date:String,number:String)  in
                
                self.openPlan(date: date, number: number)
            
            }
        }
        return footer
    }
    
    
    func openPlan(date:String,number:String){
        
        guard let login = Login.fetchLogin() else {
            assertionFailure("未登录")
            return
        }
        guard let tempJson = self.json else {
            assertionFailure("未与秤同步信息")
            return
        }
        
        do {
            let jsondata = try JSONSerialization.data(withJSONObject: tempJson, options: JSONSerialization.WritingOptions.init(rawValue: 0))
            let swifty = String.init(data: jsondata, encoding: .utf8)
            
            var body = ["body_data":swifty!,"token":login.token!,"user_id":login.user_id!] as [String : Any]
            
            if health != nil {
                let _ = body.updateValue(health!, forKey: "health")
            }
            
            if targetWeight != nil {
                let _ = body.updateValue(targetWeight!, forKey: "target_weight")
            }else{
                assertionFailure("没有填写目标体重")
            }
            
            let _ = body.updateValue(number, forKey: "number")
            let _ = body.updateValue(date, forKey: "start_time")
            
            QFNetworking.shared.post(url:QF_START_PLAN, body: body, successHandler: { (json) in
                //TODO:开启成功后
                QFManagerDisplay().loginOrRegisterSuccess()
            }, failureHandler: nil)
            
        } catch  {
            assertionFailure("转换json失败")
        }
        
    }
}
