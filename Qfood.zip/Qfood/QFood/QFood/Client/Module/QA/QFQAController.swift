/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

private let reuseIdentifier = "QACell"
private let reuseFooter = "QAFooter"

class QFQAController: QFBaseCollectionViewController {
    
    
    private let datas = ["foodquestion","bodyquestion"];
    
    convenience init() {
        let flow = UICollectionViewFlowLayout()
        
        let width = UIScreen.main.bounds.width - 44
        //图片的像素950 x 500
        let scale = width / 950.0
        let height = 500 * scale
        
        flow.itemSize = CGSize.init(width: width, height: height)
        flow.minimumLineSpacing = 37
        flow.sectionInset = UIEdgeInsets.init(top: 37, left: 22, bottom: 0, right: 22)
        flow.footerReferenceSize = CGSize.init(width:0, height: 88)
        self.init(collectionViewLayout: flow)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        collectionView!.backgroundColor = UIColor.white
        self.collectionView!.register(UINib.init(nibName: "QFQACell", bundle: nil), forCellWithReuseIdentifier: reuseIdentifier)
        collectionView!.register(UINib.init(nibName: "QFFooterView", bundle: nil), forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: reuseFooter)
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return datas.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! QFQACell
        let info = datas[indexPath.row]
        cell.icon.image = UIImage.init(named: "\(info).jpeg")
        return cell
    }

//    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        
//            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier:reuseFooter, for: indexPath) as! QFFooterView
//            footer.callback = {()->Void in
//                debugPrint("联系客服")
//                //todo:逻辑
//                
//                
//            }
//            return footer
//        
//    }
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        var temp:UIViewController?
        switch indexPath.row {
        case 0:
            temp = QFQuestionController()
        default:
//            temp = QFQuestionController.init(type: .Body)
            temp = QFSomatosensoryViewController()
            break
        }
        show(temp!, sender: nil)
        
    }
    

}
