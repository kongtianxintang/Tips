/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:只有一个label
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFLabelCell: UICollectionViewCell {

    @IBOutlet weak var desc: UILabel!
    private lazy var colors = [UIColor.textInputBackground,UIColor.gray,UIColor.brown]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let index = arc4random() % 3
        desc.textColor = colors[Int(index)]
    }

}
