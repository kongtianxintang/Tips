/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:一个lable 一个 imageview
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFOptionalCell: UICollectionViewCell {

    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var rightIcon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
    
}
