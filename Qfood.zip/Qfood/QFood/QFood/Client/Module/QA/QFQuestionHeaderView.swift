/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:1px
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFQuestionHeaderView: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
