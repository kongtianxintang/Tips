/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:历史问答cell
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFHistoryAskCell: UITableViewCell {

    @IBOutlet weak var dateLabel: UILabel!//时间
    @IBOutlet weak var questionLabel: UILabel!//问题
    @IBOutlet weak var answerLabel: UILabel!//答案
    
    //todo:用到textkit 
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
