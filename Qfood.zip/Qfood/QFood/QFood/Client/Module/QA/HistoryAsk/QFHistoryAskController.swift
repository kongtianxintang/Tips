/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:历史问答 controller
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON

class QFHistoryAskController: QFBaseTableViewController {
    
    convenience init(type:QFQuestionType) {
        self.init()
        self.type = type
    }
    
    var type:QFQuestionType = .Food
    
    let reuseID = "QFHistoryAskCell"

    //上级传出来的食物关键字
    var keyword:String?
    
    private lazy var datas:[(date:String,question:String,answer:String)] = [("2017-02-22","你是🐷吗？","不是 /\n 你才是 /\n 😄")]
    
    var jsons:[JSON]?{
        didSet{
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "历史问答"
        
        tableView.register(UINib.init(nibName: "QFHistoryAskCell", bundle: nil), forCellReuseIdentifier: reuseID)
        
        fetchData()

    }

    
    func fetchData(){
        
        let login = Login.fetchLogin()
        if login != nil ,let token = login!.token ,let userid = login!.user_id{
            
            var typestr:String!
            switch type {
            case .Body:
                typestr = "2"
            default:
                typestr = "1"
                break;
            }
            let body = ["token":token,"user_id":userid,"type":typestr] as [String : Any]
            
            QFNetworking.shared.post(url: QF_HISTORY_QUESTION, body: body, successHandler: { [unowned self](json:JSON) in
                //MARK:展示逻辑
                self.jsons = json["list"].arrayValue
                }, failureHandler: nil)
            
        }
        
        
    }
  
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return jsons == nil ? 0:1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return jsons!.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseID, for: indexPath) as! QFHistoryAskCell
        let info = jsons![indexPath.row]
        
        let time = info["add_time"].intValue
        
        let date = Date.init(timeIntervalSince1970: TimeInterval(time))
        
        
        cell.dateLabel.text = date.stringValue
        
        cell.questionLabel.text = info["q"].stringValue
        
        
        var answer = info["a"].stringValue
        if answer.characters.count <= 0 {
            answer = "暂无答案"
        }
        cell.answerLabel.text = answer
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
