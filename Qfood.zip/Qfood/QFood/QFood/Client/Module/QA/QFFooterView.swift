/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFFooterView: UICollectionReusableView {

    
    var callback:(()->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    //联系客服
    @IBAction func didClickContactService(_ sender: UIButton) {
        if callback != nil {
            callback!()
        }
    }
}
