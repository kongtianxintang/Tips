/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/14
 * QQ/Tel/Mail:
 * Description:常见问题详情
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON


class QFFAQDetailController: QFBaseTableViewController {

    let reuse = "QFHistoryAskCell"
    
    var keyword:String?
    
    var jsons:[JSON]?{
        didSet{
            tableView.reloadData()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = keyword
        
        registerCell()
        
        fetchData()
        
    }
    //注册cell
    private func registerCell(){
    
        tableView.register(UINib.init(nibName: "QFHistoryAskCell", bundle: Bundle.main), forCellReuseIdentifier: reuse)
    }
    
    func fetchData() {
        let login = Login.fetchLogin()
        if login != nil ,let token = login!.token ,let userid = login!.user_id,keyword != nil{
            
            let body = ["token":token,"user_id":userid,"group":keyword!]
            
            QFNetworking.shared.post(url: QF_FAQ_DETAILS, body: body, successHandler: { [unowned self](json:JSON) in
                self.jsons = json["list"].array
                }, failureHandler: nil)
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return jsons == nil ? 0:1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return jsons!.count
    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuse, for: indexPath) as! QFHistoryAskCell
        let json = jsons![indexPath.row]
        cell.dateLabel.text = nil
        cell.questionLabel.text = json["q"].stringValue
        cell.answerLabel.text = json["a"].stringValue
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }

}
