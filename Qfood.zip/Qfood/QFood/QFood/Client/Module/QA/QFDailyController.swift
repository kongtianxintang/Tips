/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/13
 * QQ/Tel/Mail:
 * Description:日常食物
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON


class QFDailyController: QFBaseTableViewController {

    
    private let reuse = "daily";
    
    var keyword:String?
    
    private var jsons:[JSON]?{
        didSet{
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UINib.init(nibName: "QFDailyTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: reuse)
        
        title = keyword
        
        tableView.estimatedRowHeight = 44
        tableView.separatorStyle = .singleLine
        
        
        fetchData()
    }
    
    //获取数据
    private func fetchData(){
        
        let login = Login.fetchLogin()
        
        if login != nil ,keyword != nil{
            
            let body = ["token":login!.token!,"user_id":login!.user_id!,"is_eat":keyword!];
            
            QFNetworking.shared.post(url: QF_DAILY, body: body, successHandler: { [unowned self](json) in
                self.jsons = json["foods"].arrayValue
                
                }, failureHandler: nil)
            
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return jsons == nil ? 0:jsons!.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 5
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuse, for: indexPath) as! QFDailyTableViewCell

        let info = jsons![indexPath.section]
        
        switch indexPath.row {
        case 0:
            cell.name.text = "名称:"
            cell.desc.text = info["name"].stringValue
        case 1:
            cell.name.text = "用量:"
            cell.desc.text = info["restricted"].stringValue
        case 2:
            cell.name.text = "属于:"
            cell.desc.text = info["is_eat"].stringValue
        case 3:
            cell.name.text = "分类:"
            cell.desc.text = info["type"].stringValue
        default:
            cell.name.text = "描述:"
            cell.desc.text = info["describe"].stringValue
            break;
        }

        return cell
    }
    


    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 12.0
    }
    


}
