/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:~~问题页面~~
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON
import MBProgressHUD

enum QFQuestionType {
    case Body,Food
}

class QFQuestionController: QFBaseViewController,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate{
    
    
    let labelCell = "lableCell"
    let optionalCell = "OptionalCell"
    let headerReuseID = "questionheader"
    
    @IBOutlet weak var collectionview: UICollectionView!
    
    lazy var datas = Array<Array<JSON>>()
    
//    convenience init(type:QFQuestionType) {
//        self.init()
//        self.type = type
//        
//    }
    @IBOutlet weak var searchText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "食材说明"
        
        configCollectionview()
        
        fetchData()
        
    }
    
    private func configCollectionview(){
        collectionview.register(UINib.init(nibName: "QFLabelCell", bundle: nil), forCellWithReuseIdentifier: labelCell)
        collectionview.register(UINib.init(nibName: "QFOptionalCell", bundle: nil), forCellWithReuseIdentifier: optionalCell)
        collectionview.register(UINib.init(nibName: "QFQuestionHeaderView", bundle: nil), forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: headerReuseID)
//        let flow = collectionview.collectionViewLayout as! UICollectionViewFlowLayout
//        flow.estimatedItemSize = CGSize.init(width: 50, height: 50)
        
    }
    

    //获取数据
    func fetchData(){
    
        let login = Login.fetchLogin()
        if login != nil ,let token = login!.token ,let userid = login!.user_id{
            
            let body = ["token":token,"user_id":userid]
            
            QFNetworking.shared.post(url: QF_FOOD, body: body, successHandler: { [unowned self](json:JSON) in
                //MARK:展示逻辑
                
                let foods = json["foods"].arrayValue
                let iseats = json["is_eats"].arrayValue
                self.datas.append(foods)
                self.datas.append(iseats)
                self.collectionview.reloadData()
            }, failureHandler: nil)
            
        }
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //搜索
    @IBAction func didClickSearch(_ sender: UIButton) {
    
        guard let text = searchText.text else {
            QFHubManager.showToast(self.view, text: "您还没输入")
            return
        }
        if text.characters.count <= 0 {
            QFHubManager.showToast(self.view, text: "您还没输入")
            return
        }
        showSearchController(text: text)
    }
    
    //push出搜索
    func showSearchController(text:String){
        let foodvc = QFFoodController()
        foodvc.keyword = text
        show(foodvc, sender: nil)
    }
    

    //uicollectionview datasource delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return datas.count

    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return datas[section].count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell:UICollectionViewCell?
        switch indexPath.section {
        case 0:
            let  labelcell = collectionView.dequeueReusableCell(withReuseIdentifier: labelCell, for: indexPath) as! QFLabelCell
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row]["name"].stringValue
            labelcell.desc.text = json
            cell = labelcell
            break;
        default:
            let  optioncell = collectionView.dequeueReusableCell(withReuseIdentifier: optionalCell, for: indexPath) as! QFOptionalCell
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row]["is_eat"].stringValue
            optioncell.desc.text = json
            cell = optioncell
            break;
        }
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch indexPath.section {
        case 0:
            let width = (collectionView.bounds.size.width - 40 ) / 4
            return CGSize.init(width: width  , height: 40)
        default:
            return CGSize.init(width: collectionView.bounds.size.width - 40, height: 56)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: headerReuseID, for: indexPath)
        return  header
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //todo:点击逻辑
        switch indexPath.section {
        case 0:
            
            let history = QFFoodController()
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row]["name"].stringValue
            history.keyword = json
            show(history, sender: nil)
            
        default:
            
            let history = QFDailyController()
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row]["is_eat"].stringValue
            history.keyword = json
            show(history, sender: nil)
            
            break;
        }
    }
    
    
    
    //历史问答
    @IBAction func didClickHistoryQuestion(_ sender: UIButton) {
        let history = QFHistoryAskController.init(type: .Food)
        show(history, sender: nil)
    }
    
    //我要提问
    @IBAction func didClickAskQuestion(_ sender: UIButton) {
        let ask = QFAskQuestionViewController.init(type: .Food)
        show(ask, sender: nil)
    }
    

}
