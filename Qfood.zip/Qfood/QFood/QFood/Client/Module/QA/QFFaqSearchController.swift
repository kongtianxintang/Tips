/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/14
 * QQ/Tel/Mail:
 * Description:问题搜索
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON

class QFFaqSearchController: QFFAQDetailController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    override func fetchData() {
        let login = Login.fetchLogin()
        if login != nil ,let token = login!.token ,let userid = login!.user_id,keyword != nil{
            
            let body = ["token":token,"user_id":userid,"keyword":keyword!]
            
            QFNetworking.shared.post(url: QF_SEARCH_FAQ, body: body, successHandler: { [unowned self](json:JSON) in
            
                self.jsons = json["faq"].array
                }, failureHandler: nil)
            
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }


    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */


}
