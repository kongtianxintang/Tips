/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:我要提问页面
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import TZImagePickerController
import MBProgressHUD
import SwiftyJSON


class QFAskQuestionViewController: QFBaseViewController,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,TZImagePickerControllerDelegate{
    
    convenience init(type:QFQuestionType) {
        self.init()
        self.type = type
    }
    
    private var type:QFQuestionType = .Food
    
    @IBOutlet weak var feedback: UITextView!
    @IBOutlet weak var collectionview: UICollectionView!

    private var flowlayout:UICollectionViewFlowLayout?
    
    private lazy var images:Array<UIImage> = Array()
    
    //数据源
    private lazy var datas:[(img:UIImage,isEdit:Bool)] = Array()
    
    //图片选择
    private lazy var pick:TZImagePickerController = {
        return TZImagePickerController.init(maxImagesCount: 4, delegate: self)
    }()
    
    private lazy var addImg = UIImage.init(named: "add")!
    
    private let reuseId = "QFAskCell"
    
    
    private lazy var upmanager = QFUpYunManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //
//        images.append(addImage)
        datas.append((addImg,false))
        collectionview.register(UINib.init(nibName: "QFAskCell", bundle: nil), forCellWithReuseIdentifier: reuseId)
        title = "我要提问"
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    override func viewDidLayoutSubviews() {
        
        if flowlayout == nil{
            
        }
    }
    
    //#collectionview datasource delegate
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (collectionView.bounds.size.width - 24 ) / 4
        let size = CGSize.init(width: width, height: width)
        return size
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return datas.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseId, for: indexPath) as! QFAskCell
        let info = datas[indexPath.row]
        cell.info = info
        
        if !info.isEdit {
            //此图片是add
            cell.deleteButton.isHidden = true
        }
        
        //删除上传图片的逻辑～～
        cell.callback = {[unowned self]()->Void in
            
            self.datas.remove(at: indexPath.row)
            //判断图片数组是否包含 addimage 这张图 ,如果没有的话添加上去
            if !self.datas.contains(where: { (temp:(img: UIImage, isEdit: Bool)) -> Bool in
                return  temp.isEdit == false
            }) {
                self.datas.append((img:self.addImg,false))
            }
            self.collectionview.reloadData()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let info = datas[indexPath.row]
        //是真的图片
        if info.isEdit {
            return
        }
        
        let count = 5 - datas.count
        
        pick.maxImagesCount = count
        
        present(pick, animated: true, completion: nil)
        
    }
    
    //#tzimagepickcontroller delegate
    func imagePickerController(_ picker: TZImagePickerController!, didFinishPickingPhotos photos: [UIImage]!, sourceAssets assets: [Any]!, isSelectOriginalPhoto: Bool) {
        
        for item in photos {
            datas.insert((item,true), at: 0)
        }
        
        if datas.count >= 5 {
            //如果超过了限制就把最后一张add的图删掉
            datas.removeLast()
        }
        
        collectionview.reloadData()
    }
    
    //点击提交
    @IBAction func didClickSubmit(_ sender: UIButton) {
        
        let key = UIApplication.shared.keyWindow!
        guard let text = feedback.text else {
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.removeFromSuperViewOnHide = true
            hub.label.text = "提问描述不能为空"
            hub.hide(animated: true, afterDelay: 2.0)
            return
        }
        if text.characters.count <= 0 {
            return
        }
        
        //获取到图片 转化成data
        var temp = Array<Data>()
        for item in datas {
            if item.isEdit {
                if let data = UIImageJPEGRepresentation(item.img, 0.6) {
                    temp.append(data)
                }
            }
        }
        
        upmanager.uploaderMulti(datas: temp, bucketType: .QuestionPic) {[unowned self] (pics:String) in
//            debugPrint("图片路径=\(pics)")
            
            let login = Login.fetchLogin()
            if login != nil ,let token = login!.token ,let userid = login!.user_id{
                
                var typestr:String!
                
                switch self.type {
                
                case .Body:
                    typestr = "2"
                default:
                    typestr = "1"
                    break;
                    
                }
                do {
                    //普通路径转成json形式
                    let swiftys = pics.components(separatedBy: ",")
                    let jsondata = try JSONSerialization.data(withJSONObject: swiftys, options: JSONSerialization.WritingOptions.prettyPrinted)
                    let swifty = String.init(data: jsondata, encoding: .utf8)
//                    debugPrint("tttt=\(swifty)")
                    if swifty != nil{
                        let body = ["token":token,"user_id":userid,"type":typestr,"question":text,"pics":swifty!] as [String : Any]
                    
                        DispatchQueue.main.async {
                            QFNetworking.shared.post(url: QF_ADD_QUESTION, body: body, successHandler: { [unowned self](json:JSON) in
                            //MARK:展示逻辑
                            let _ = self.navigationController!.popViewController(animated: true)
                            
                            let key = UIApplication.shared.keyWindow!
                            let hub = MBProgressHUD.showAdded(to: key, animated: true)
                            hub.mode = .text
                            hub.label.text = "提问成功"
                            hub.hide(animated: true, afterDelay: 1.0)
                            }, failureHandler: nil)
                    }
                }
                }catch{
                    assertionFailure("转换json错误=\(error)")
                }
            }
        }
        
    }
    

}
