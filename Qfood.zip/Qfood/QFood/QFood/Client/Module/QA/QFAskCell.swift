/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:我要提问页面展示图片的cell
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFAskCell: UICollectionViewCell {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    
    var callback:(()->Void)?
    
    
    var info:(img:UIImage,isEdit:Bool)?{
        didSet{
            icon.image = info?.img
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let long = UILongPressGestureRecognizer.init(target: self, action:#selector(longpressGestureRecognizerAction(longpress:)))
        addGestureRecognizer(long)
    }
    
    
    
    @IBAction func didClickDeleteItem(_ sender: UIButton) {
        
        sender.isHidden = true
        //删除回调
        if callback != nil {
            callback!()
        }
    }

    //常按手势时间
    func longpressGestureRecognizerAction(longpress:UILongPressGestureRecognizer){
        
        guard let temp = info else {
            return
        }
        
        //是否可以编辑
        if temp.isEdit  {
            if longpress.state == .began {

                if deleteButton.isHidden {
                    
                    //抖动效果
                    let keyAnimation = CAKeyframeAnimation()
                    keyAnimation.keyPath = "transform.rotation"
                    keyAnimation.duration = 0.5
                    keyAnimation.repeatCount = 12
                    keyAnimation.values = [(-(M_PI / 45)),(M_PI / 45),(-(M_PI / 45))]
                    layer.add(keyAnimation, forKey: nil)
                    
                    deleteButton.isHidden = false
                    
                }
            }
        }
    }
    
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
    
}
