/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/13
 * QQ/Tel/Mail:
 * Description:体感指导
 * Others:todo
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON

class QFSomatosensoryViewController: QFQuestionController {

    convenience init(){
        self.init(nibName:"QFQuestionController",bundle:Bundle.main)
    }
  
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "体感指导"
        
    }
    
    //获取数据
    override  func  fetchData(){
        
        let login = Login.fetchLogin()
        if login != nil ,let token = login!.token ,let userid = login!.user_id{
            
            let body = ["token":token,"user_id":userid]
            
            QFNetworking.shared.post(url: QF_SOMATOSENSORY, body: body, successHandler: { [unowned self](json:JSON) in
                //MARK:展示逻辑
                let foods = json["list"].arrayValue
                let hotkeyword = json["hotKeyWord"].arrayValue
                self.datas.append(hotkeyword)
                self.datas.append(foods)
                self.collectionview.reloadData()
                }, failureHandler: nil)

        }
    }
    
    
    override func showSearchController(text: String) {
        let detailVC = QFFaqSearchController()
        detailVC.keyword = text
        show(detailVC, sender: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.section {
        case 0:
            
            let history = QFFaqSearchController()
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row].stringValue
            history.keyword = json
            show(history, sender: nil)
            
        default:
            
            let history = QFFAQDetailController()
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row]["group"].stringValue
            history.keyword = json
            show(history, sender: nil)
            
            break;
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell:UICollectionViewCell?
        switch indexPath.section {
        case 0:
            let  labelcell = collectionView.dequeueReusableCell(withReuseIdentifier: labelCell, for: indexPath) as! QFLabelCell
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row].stringValue
            labelcell.desc.text = json
            cell = labelcell
            break;
        default:
            let  optioncell = collectionView.dequeueReusableCell(withReuseIdentifier: optionalCell, for: indexPath) as! QFOptionalCell
            let jsons = datas[indexPath.section]
            let json = jsons[indexPath.row]["group"].stringValue
            optioncell.desc.text = json
            cell = optioncell
            break;
        }
        return cell!
    }
    
    
    override func didClickAskQuestion(_ sender: UIButton) {
        let ask = QFAskQuestionViewController.init(type: .Body)
        show(ask, sender: nil)
    }
    
    override func didClickHistoryQuestion(_ sender: UIButton) {
        let history = QFHistoryAskController.init(type: .Body)
        show(history, sender: nil)
    }
    
    
    
    
    

}
