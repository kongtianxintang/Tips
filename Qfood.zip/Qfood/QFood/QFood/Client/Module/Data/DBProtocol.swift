/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/01
 * QQ/Tel/Mail:
 * Description:协议
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/
import Foundation
import SwiftyJSON

protocol QFDatabaseProtocol {
    
    //保存
    static func contextSave(json:JSON) -> Bool
    //删除
    static func contextDelete()->Bool
    //insert ~插入
    func contextInsert()->Bool
    //删除
//    func contextRemove()->Bool
    
}
extension QFDatabaseProtocol {
    
    //默认实现
    static func contextSave(json:JSON)->Bool{
        return false
    }
    static func contextDelete()->Bool{
        return false
    }
    func contextInsert()->Bool{
        return false
    }
//    func contextRemove()->Bool{
//        return false
//    }
    
}
