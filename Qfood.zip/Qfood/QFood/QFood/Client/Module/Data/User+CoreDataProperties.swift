/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/23
 * QQ/Tel/Mail:
 * Description:用户信息保存
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import Foundation
import CoreData
import SwiftyJSON


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User");
    }

    @NSManaged public var height: Int16
    @NSManaged public var user_nikname: String?
    @NSManaged public var target_weight: Float
    @NSManaged public var user_avatar: String?
    @NSManaged public var birthday: String?
    @NSManaged public var sex: Int16
    @NSManaged public var s: String?
    

}
extension User : QFDatabaseProtocol{
    
   static func contextSave(json: JSON) -> Bool {
        if let context = QFDatabase.shared.createContext(){
            
            let entity = NSEntityDescription.insertNewObject(forEntityName: "User", into: context)
            entity.setValue(json["user_nikname"].stringValue, forKey: "user_nikname")
            entity.setValue(json["user_avatar"].stringValue, forKey: "user_avatar")
            entity.setValue(json["s"].stringValue, forKey: "s")
            entity.setValue(json["height"].int16Value, forKey: "height")
            entity.setValue(json["target_weight"].floatValue, forKey: "target_weight")
            entity.setValue(json["sex"].int16Value, forKey: "sex")
            entity.setValue(json["birthday"].stringValue, forKey: "birthday")
            do{
                try context.save()
                return true
            }catch let error{
                assertionFailure("\(error)")
            }
        }
        return false
    }
    
   static func contextDelete() -> Bool {
        
        guard let context = QFDatabase.shared.createContext() else {
            return false
        }
        
        let request:NSFetchRequest<User> = User.fetchRequest()
    
        let sort = NSSortDescriptor.init(key: "height", ascending: true)
    
        request.sortDescriptors = [sort]
        
        let results = NSFetchedResultsController.init(fetchRequest: request, managedObjectContext:context, sectionNameKeyPath: nil, cacheName: nil)
        
        do {
            try results.performFetch()
            guard let objs = results.fetchedObjects else{ return false }
            
            for item in objs {
                context.delete(item)
            }
            do {
                try context.save()
                return true
            } catch  {
                assertionFailure("coredata保存失败")
            }
            
        } catch  {
            assertionFailure("我也不知道这个错误是啥^-^")
        }
        
        return false
    }
    
    class func contextFetchUser()-> User? {
        
        guard let tempcontext = QFDatabase.shared.createContext() else {  return nil }
        
        let request:NSFetchRequest<User> = User.fetchRequest()
        
        let sort = NSSortDescriptor.init(key: "height", ascending: true)
        request.sortDescriptors = [sort]
        let results = NSFetchedResultsController.init(fetchRequest: request, managedObjectContext:tempcontext, sectionNameKeyPath: nil, cacheName: nil)
        do {
            try results.performFetch()
            let fetchs = results.fetchedObjects
            
            if fetchs != nil , fetchs!.count > 0 {
                return fetchs![0] as User
            }
            return nil
        } catch  {
            assertionFailure("error\(error)")
            return nil
        }
    
    }

}
