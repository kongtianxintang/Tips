/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/02
 * QQ/Tel/Mail:
 * Description:
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import Foundation
import CoreData


extension Login {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Login> {
        return NSFetchRequest<Login>(entityName: "Login");
    }
    

    @NSManaged public var token: String?
    @NSManaged public var user_id: String?
    @NSManaged public var task_logId: Int64
    
    class func fetchLogin()->Login?{
    
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init()
        
        guard let tempcontext = QFDatabase.shared.createContext() else {  return nil }
        
        let entity = NSEntityDescription.entity(forEntityName: "Login", in:tempcontext)
        let sort = NSSortDescriptor.init(key: "token", ascending: true)
        fetchRequest.entity = entity
        fetchRequest.sortDescriptors = [sort]
        let results = NSFetchedResultsController.init(fetchRequest: fetchRequest, managedObjectContext:tempcontext, sectionNameKeyPath: nil, cacheName: nil)
        do {
            try results.performFetch()
            let fetchs = results.fetchedObjects
            if fetchs != nil , fetchs!.count > 0 {
                return fetchs![0] as? Login
            }
            return nil
        } catch  {
            assertionFailure("error\(error)")
            return nil
        }
    }
    
}
