/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/23
 * QQ/Tel/Mail:
 * Description:用户信息保存
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
