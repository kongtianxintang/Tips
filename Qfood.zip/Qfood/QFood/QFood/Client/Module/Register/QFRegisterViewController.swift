/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:注册页
 * Others: TODO:验证码请求倒计时
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import MBProgressHUD
import SwiftyJSON
import CoreData

enum QFRegisterType:Int8{
    
    case register,forgetPW
    
}

class QFRegisterViewController: QFBaseViewController {

    
    private lazy var type:QFRegisterType = .register
    
    @IBOutlet weak var verifyCodeBackground: UIView!
    @IBOutlet weak var passwordBackground: UIView!
    @IBOutlet weak var telephoneBackground: UIView!
    @IBOutlet weak var registerButton: UIButton!
    
    
    
    @IBOutlet weak var code: UITextField!
    @IBOutlet weak var telephone: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var protolBackview: UIView!
    
    convenience init(type:QFRegisterType) {
        self.init()
        self.type = type
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configCellBoardColor()
    }

    
    //设置边框颜色和大小
    private func configCellBoardColor(){
        verifyCodeBackground.layer.borderColor = UIColor.textInputBackground.cgColor
        passwordBackground.layer.borderColor = UIColor.textInputBackground.cgColor
        telephoneBackground.layer.borderColor = UIColor.textInputBackground.cgColor
        
        switch type {
        case .forgetPW:
            title = "忘记密码"
            registerButton.setTitle("重置", for: .normal)
            protolBackview.isHidden = true
        default:
            title = "注册"
        }
    }
    
    //MARK:获取验证码
    @IBAction func didClickGetSMS(_ sender: UIButton) {
        
        if checkTelephone() {
            
            var body = ["mobile":telephone.text!]
            
            if type == .forgetPW {
                body.updateValue("resetpwd", forKey: "type")
            }
            
            QFNetworking.shared.post(url: QF_SMS, body: body, successHandler: { (json) in
                
                let countdown = sender as! QFCountdownButton
                countdown.startTimer()
                
            }, failureHandler: nil)
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func didClickRegister(_ sender: UIButton) {
        
        if checkTelephone() && checkCode() && checkPassword() {
            let body = ["mobile":telephone.text!,"code":code.text!,"password":password.text!]
            
            var path = QF_REGISTER
            switch type {
            case .forgetPW:
                path = QF_RESETPWD
            default:
                break;
            }

            QFNetworking.shared.post(url: path, body: body, successHandler: {[unowned self] (json) in
                
                switch self.type {
                case .forgetPW:
                    let key = UIApplication.shared.keyWindow!
                    let hub = MBProgressHUD.showAdded(to:key , animated: true)
                    hub.mode = .text
                    hub.label.text = "密码重置成功"
                    hub.hide(animated: true, afterDelay: 4.0)
                    self.navigationController!.popViewController(animated: true)
                default:
                    //获取到用户数据并保存到本地
                    if let context = QFDatabase.shared.createContext(){
                        
                        let entity = NSEntityDescription.insertNewObject(forEntityName: "Login", into: context)
                        entity.setValue(json["token"].stringValue, forKey: "token")
                        entity.setValue(json["user_id"].stringValue, forKey: "user_id")
                        entity.setValue(0, forKey: "task_logId")
                        do{
                            try context.save()
                            
                        }catch let error{
                            assertionFailure("\(error)")
                        }
                    }
                    //MARK:注册成功后到显示资料填充页
                    QFManagerDisplay().displayGuide()
                    
                    break;
                }
                
                
            }, failureHandler: nil)
        }
        
    }
    
    
    @IBAction func didClickUserAgreement(_ sender: UIButton) {
        //TODO:用户协议
        
    }
    
    //MARK:验证码验证
    private func checkCode() -> Bool{
        
        guard let smscode = code.text else {
            return false
        }
        //验证码4位
        if smscode.characters.count < 4 {
            return false
        }
        return true
    }
    //MARK:验证手机号是否规范
    private func checkTelephone()->Bool{
        guard let telephoneNum = telephone.text else {
            return false
        }
        let isvail = LWRegular.phoneNum(telephoneNum).isRight
        
        if !isvail {
            let key = UIApplication.shared.keyWindow!
            let hub = MBProgressHUD.showAdded(to: key, animated: true)
            hub.mode = .text
            hub.label.text = "无效的手机号"
            hub.hide(animated: true, afterDelay: 2.0)
            return false
        }
        return true
    }
    
    //MARK:验证密码规范
    private func checkPassword()->Bool{
    
        guard let pass = password.text else {
            return false
        }
        if pass.characters.count <= 0 {
            return false
        }
        return true
    }

    

}
