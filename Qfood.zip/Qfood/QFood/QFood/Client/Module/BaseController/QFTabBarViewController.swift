/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:基础tabbarcontroller
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import ESTabBarController_swift
import SwiftyJSON
import MBProgressHUD

class QFTabBarViewController: ESTabBarController {
    
    var rightBar:UIBarButtonItem?
    
    private lazy var list:[(className:String,selectedImage:String,nonmarlImage:String,title:String)] = [("QFTaskController","icon_renwu","icon_renwu","任务"),("QFQAController","icon_wenda","icon_wenda","问答"),("QFSettingViewController","icon_shezhi","icon_shezhi","设置")]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        var controllers = Array<UIViewController>()
        
        for item in list {
            let classStr = "QFood." + item.className
            guard let aClass = NSClassFromString(classStr) else { return }
            let t  = aClass as! UIViewController.Type
            let controller = t.init()
            controller.tabBarItem = ESTabBarItem.init(QFTabbarView(), title:item.title, image: setTabBarItem(name: item.nonmarlImage), selectedImage: setTabBarItem(name: item.selectedImage))
            controllers.append(controller)
        }
        if let tabBar = tabBar as? ESTabBar {
            tabBar.itemCustomPositioning = .fillIncludeSeparator
        }
        tabBar.isTranslucent = false
        tabBar.itemSpacing = 0.5
        viewControllers = controllers
        
        QFLeftBarButtonItem()
        
    }
    
    private func setTabBarItem(name:String)->UIImage{
        return UIImage.init(named: name)!.withRenderingMode(UIImageRenderingMode.alwaysOriginal)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func QFLeftBarButtonItem(){
    
    
        rightBar = UIBarButtonItem.init(image: UIImage.init(named: "scale"), style: .done, target: self, action: #selector(rightBarItemAction))
        
        navigationItem.rightBarButtonItem = rightBar
    }
    
    
    func rightBarItemAction(baritem:UIBarButtonItem){
        let scale = QFScaleController()
        scale.showScaleController()
        scale.callback = { (result:TFScaleResult) in
            //MARK:添加蓝牙数据
            self.addBodyData(result: result)
        }
        scale.failureBlock = {[unowned self] in
            //MARK:去打开蓝牙
            self.bluetoothPoweredOffAction()
            
        }
        
    }
    
    private func bluetoothPoweredOffAction(){
        
        let alert = UIAlertController()
        let cancel = UIAlertAction.init(title: "取消", style: UIAlertActionStyle.cancel, handler: nil)
        let sure = UIAlertAction.init(title: "去开启蓝牙", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
            //MARK:去开启蓝牙
            let url = URL.init(string: "App-Prefs:root=Bluetooth")
            if nil != url {
                if UIApplication.shared.canOpenURL(url!){
                    UIApplication.shared.openURL(url!)
                }
            }
        }
        alert.addAction(cancel)
        alert.addAction(sure)
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    private func showOpenPlan(result:TFScaleResult){
        
        //TODO:逻辑～什么时候开启
        let alert = QFAlertViewController()
        
        //TODO:从蓝牙获取数据
        
        let normal = [NSForegroundColorAttributeName:UIColor.lightGray,NSFontAttributeName:UIFont.systemFont(ofSize: 15)]
        
        let number = [NSForegroundColorAttributeName:UIColor.gray,NSFontAttributeName:UIFont.systemFont(ofSize: 17)]
        
        let kg = [NSFontAttributeName:UIFont.systemFont(ofSize: 15),NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground]
        
        let current = NSMutableAttributedString.init(string: "您的当前体重:", attributes: normal)
        current.append(NSAttributedString.init(string: " \(result.weight) ", attributes: number))
        current.append(NSAttributedString.init(string: "KG\n", attributes: kg))
        
        
        let standard = NSMutableAttributedString.init(string: "您的标准体重:",attributes:normal)
        standard.append(NSAttributedString.init(string: " \(result.sw) ", attributes: number))
        standard.append(NSAttributedString.init(string: "KG", attributes: kg))
        
        current.append(standard)
        
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineSpacing = 5.0
        paragraph.alignment = .center
        
        current.addAttributes([NSParagraphStyleAttributeName:paragraph], range: NSRange.init(location: 0, length: current.length))
        
        alert.showPlan(attributedText: current)
        
        //true 开启方案 flase 不开启方案
        alert.clickBlock = { [unowned self] (flag:Bool,target:String?) in
            
            if flag {
                
                let json = ["Weight":result.weight,"muscle":result.muscleWeight,"Calorie":0,"VisceralFat":result.visceralFatPercentage,"Bone":result.boneWeight,"bmi":result.bmi,"water":result.waterWeight]
                
                let report = QFReportController()
                report.json = json
                report.targetWeight = target
                self.show(report, sender: nil)
            }
        }
        
    }
    
    private func addBodyData(result:TFScaleResult){
    
        
        guard let login = Login.fetchLogin() else {
            //用户未登录
            assertionFailure("用户未登录")
            return
        }
        
        if login.task_logId == 0 {
            //用户还没有开启方案 ~ 引导用户去开启方案
            showOpenPlan(result: result)
            return
        }
        
        
        let json = ["Weight":result.weight,"muscle":result.muscleWeight,"Calorie":0,"VisceralFat":result.visceralFatPercentage,"Bone":result.boneWeight,"bmi":result.bmi,"water":result.waterWeight]
        do {
           let data = try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.init(rawValue: 0))
        
            if let swiftyjson = String.init(data: data, encoding: .utf8) {
                    
                    let body = ["token":login.token!,"user_id":login.user_id!,"task_logId":login.task_logId,"body_data":swiftyjson] as [String : Any]
                
                
                    QFNetworking.shared.post(url: QF_ADD_BODY_DATA, body: body, successHandler: {[unowned self] (json:JSON) in
                        
                        DispatchQueue.main.async {
                            QFHubManager.showToast(self.view, text: "蓝牙数据更新成功")
                        }
                        
                    }, failureHandler: nil)
                
            }else{
                assertionFailure("json转化成string失败")
            }
        } catch  {
            assertionFailure("转化json失败=\(error)")
        }
        
    }
    

//    deinit {
//        debugPrint("销毁\(self.classForCoder)")
//    }

}
