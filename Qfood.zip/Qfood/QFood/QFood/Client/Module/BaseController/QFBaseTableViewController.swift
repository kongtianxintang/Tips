/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:基础tableviewcontroller
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import DZNEmptyDataSet

class QFBaseTableViewController: UITableViewController,DZNEmptyDataSetSource,DZNEmptyDataSetDelegate{

    var isLoading:Bool = false {
        didSet{
            self.tableView.reloadEmptyDataSet()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = .none
        tableView.estimatedRowHeight = 44
        tableView.emptyDataSetSource = self
        tableView.emptyDataSetDelegate = self
        tableView.tableFooterView = UIView()
//        tableView.backgroundColor = UIColor.QFlightCellBackground
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK:empty data set source delegate
    func title(forEmptyDataSet scrollView: UIScrollView!) -> NSAttributedString! {
        let text = "没有数据"
        let font = UIFont.init(name: "HelveticaNeue-Light", size: 22.0)
        let textColor = UIColor.init(hexString: "c9c9c9")
        let attri = NSAttributedString.init(string: text, attributes: [NSForegroundColorAttributeName:textColor,NSFontAttributeName:font!])
        return attri
    }
//    //描述
//    func description(forEmptyDataSet scrollView: UIScrollView!) -> NSAttributedString! {
//        let text = "测试"
//        let font = UIFont.systemFont(ofSize: 13.0)
//        let textColor = UIColor.init(hexString: "cfcfcf")
//        let attri = NSAttributedString.init(string: text, attributes: [NSFontAttributeName:font,NSForegroundColorAttributeName:textColor])
//        return attri
//    }
    func imageAnimation(forEmptyDataSet scrollView: UIScrollView!) -> CAAnimation! {
        
        let animation = CABasicAnimation.init(keyPath: "transform")
        animation.fromValue = NSValue.init(caTransform3D: CATransform3DIdentity)
        animation.toValue = NSValue.init(caTransform3D: CATransform3DMakeRotation(CGFloat(M_PI * 2.0), 0.0, 0.0, 1.0))
        animation.duration = 0.25;
        animation.isCumulative = true;
        animation.repeatCount = MAXFLOAT;
        return animation;
    }
    
    func image(forEmptyDataSet scrollView: UIScrollView!) -> UIImage! {
        if isLoading {
            return UIImage.init(named: "loading")
        }
        return UIImage.init(named: "empty")
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView!, for state: UIControlState) -> NSAttributedString! {
        let text = "点击刷新"
        let font = UIFont.systemFont(ofSize: 16.0)
        let textColor = UIColor.init(hexString: (state == UIControlState.normal) ? "05adff" : "6bceff")
        return NSAttributedString.init(string: text, attributes: [NSForegroundColorAttributeName:textColor,NSFontAttributeName:font])
    }
    
    func emptyDataSet(_ scrollView: UIScrollView!, didTap button: UIButton!) {
        isLoading = true;
        DispatchQueue.main.asyncAfter(deadline:.now() + 2.0) {
            self.isLoading = false
        }
    }
    
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }
    
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }

}
