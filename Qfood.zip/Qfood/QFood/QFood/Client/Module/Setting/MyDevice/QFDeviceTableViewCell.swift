/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:设备页的cell
 * Others:todo 逻辑
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFDeviceTableViewCell: UITableViewCell {
    @IBOutlet weak var deviceBackground: UIView!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var deviceSwitch: UISwitch!
    @IBOutlet weak var accompany: UILabel!
    @IBOutlet weak var indicate: UIImageView!
    

    
    var device:QFDeviceModel?{
        didSet{
            desc.text = device!.deviceName
            if device!.state {
                deviceBackground.backgroundColor = UIColor.lightGreen
                deviceSwitch.isOn = true
                desc.textColor = UIColor.QFdeviceValidText
            }else{
                deviceSwitch.isOn = false
                deviceBackground.backgroundColor = UIColor.QFlightCellBackground
                desc.textColor = UIColor.gray
            }
        }
    }
    
    var sysInfo:QFSysModel?{
        didSet{
            desc.text = sysInfo!.name
            desc.textColor = UIColor.gray
            if sysInfo!.accompany != nil {
                accompany.isHidden = false
                accompany.text = sysInfo!.accompany
                deviceSwitch.isHidden = true
                indicate.isHidden = true
                deviceBackground.backgroundColor = UIColor.QFlightCellBackground
                
            }
            if sysInfo!.isSwitch != nil {
                deviceSwitch.isHidden = false
                accompany.isHidden = true
                indicate.isHidden = true
                deviceSwitch.isOn = sysInfo!.isSwitch!
                if sysInfo!.isSwitch! {
                    desc.textColor = UIColor.QFdeviceValidText
                    deviceBackground.backgroundColor = UIColor.lightGreen
                }else{
                    desc.textColor = UIColor.gray
                    deviceBackground.backgroundColor = UIColor.QFlightCellBackground
                }
                
                
            }
            if sysInfo!.indicator != nil {
                deviceSwitch.isHidden = true
                accompany.isHidden = true
                indicate.isHidden = false
                indicate.image = UIImage.init(named: sysInfo!.indicator!)
                deviceBackground.backgroundColor = UIColor.QFlightCellBackground
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    
    @IBAction func didClickChangeState(_ sender: UISwitch) {
        
        //todo:此处还要做逻辑处理
        if sender.isOn {
            deviceBackground.backgroundColor = UIColor.lightGreen
            desc.textColor = UIColor.QFdeviceValidText
        }else{
            deviceBackground.backgroundColor = UIColor.QFlightCellBackground
            desc.textColor = UIColor.gray
        }
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
}
