/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/17
 * QQ/Tel/Mail:
 * Description:我的设备
 * Others:TODO 逻辑方面未完成 只搭建ui
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

struct QFDeviceModel {
    var state:Bool = false
    var deviceName:String = "未知设备"
}

class QFMyDeviceViewController: QFBaseTableViewController {

    private let cellReuseID = "QFDeviceTableViewCell"
    
    private lazy var datas:[QFDeviceModel] = {
        var list = Array<QFDeviceModel>()
        let names = ["体脂秤","血压计","血糖仪"];
        
        //体脂
        var weight = QFDeviceModel()
        weight.deviceName = names[0]
        weight.state = true
        list.append(weight)
        
        //血压
        var bloodPressure = QFDeviceModel()
        bloodPressure.deviceName = names[1]
        list.append(bloodPressure)
        
        //血糖
        var bloodSuar = QFDeviceModel()
        bloodSuar.deviceName = names[2]
        list.append(bloodSuar)
        
        
        return list
    }()
    override func viewDidLoad() {
        super.viewDidLoad()

       title = "我的设备"
        
        registerCell()
        
    }
    
    
    
    private func registerCell(){
        tableView.register(UINib.init(nibName: "QFDeviceTableViewCell", bundle: nil), forCellReuseIdentifier: cellReuseID)
//        tableView.estimatedRowHeight = 44
//        tableView.separatorStyle = .none
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return datas.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseID, for: indexPath) as! QFDeviceTableViewCell
        let model = datas[indexPath.row]
        cell.device = model
        return cell
    }
    


}
