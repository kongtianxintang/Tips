/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/17
 * QQ/Tel/Mail:
 * Description:系统设置
 * Others:TODO 逻辑方面未完成 只搭建ui
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import UserNotifications


struct QFSysModel {
    var name:String = "未知"
    var isSwitch:Bool?//是否有uiswitch
    var accompany:String?//
    var indicator:String?
}

class QFSystemTableViewController: QFBaseTableViewController {

    
    private lazy var datas:[QFSysModel] = {
    
        var list = Array<QFSysModel>()
        
        var apns = QFSysModel()
        apns.name = "消息推送-已开启"
        apns.isSwitch = true
        list.append(apns)
        
        var cache = QFSysModel()
        cache.name = "清除缓存"
        cache.accompany = "0M"
        list.append(cache)
        
        var about = QFSysModel()
        about.name = "关于Nutribody"
        about.indicator = "arrow-right"
        list.append(about)
        
        var update = QFSysModel()
        update.name = "检查更新"
        update.accompany = "最新版本1.0"
        list.append(update)
        
        return list
    
    }()
    
    
    private lazy final var  reuseID = "QFDeviceTableViewCell"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "系统设置"
        
        if #available(iOS 10, *){
            
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge,.sound,.alert], completionHandler: { [unowned self] (grander, error) in
                
                if grander {
                    
                }else{
                    self.datas[0].isSwitch = false
                    self.datas[0].name = "消息推送-已关闭"
                    DispatchQueue.main.async {
                        self.tableView.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: UITableViewRowAnimation.automatic)
                    }
                    
                }
            })
        
        }else{
            //TODO:iOS10.0之前的消息通知
            
            
        }
        registerCell();
        
    }

    
    private func registerCell(){
    
        tableView.register(UINib.init(nibName: "QFDeviceTableViewCell", bundle: nil), forCellReuseIdentifier: reuseID)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return datas.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseID, for: indexPath) as! QFDeviceTableViewCell
        let info = datas[indexPath.row]
        cell.sysInfo = info
        return cell
    }
    

}
