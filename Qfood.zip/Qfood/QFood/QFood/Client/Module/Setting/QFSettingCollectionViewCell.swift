/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/16
 * QQ/Tel/Mail:
 * Description:
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFSettingCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var icon: UIImageView!

    @IBOutlet weak var desc: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        contentView.backgroundColor = UIColor.init(red: 214 / 255.0, green: 231 / 255.0, blue: 172 / 255.0, alpha: 1)
//        layer.shouldRasterize = true
//        layer.rasterizationScale = UIScreen.main.scale
    }
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
}
