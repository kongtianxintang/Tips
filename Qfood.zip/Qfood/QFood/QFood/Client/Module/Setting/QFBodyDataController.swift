/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/03/28
 * QQ/Tel/Mail:
 * Description:身体数据～～TODO:暂时不开放
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFBodyDataController: QFBaseTableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        title = "身体数据"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }
    
    
    //MARK:empty data set source delegate
    override func title(forEmptyDataSet scrollView: UIScrollView!) -> NSAttributedString! {
        let text = "此功能暂未开放"
        let font = UIFont.init(name: "HelveticaNeue-Light", size: 22.0)
        let textColor = UIColor.init(hexString: "c9c9c9")
        let attri = NSAttributedString.init(string: text, attributes: [NSForegroundColorAttributeName:textColor,NSFontAttributeName:font!])
        return attri
    }
    //    //描述
    //    func description(forEmptyDataSet scrollView: UIScrollView!) -> NSAttributedString! {
    //        let text = "测试"
    //        let font = UIFont.systemFont(ofSize: 13.0)
    //        let textColor = UIColor.init(hexString: "cfcfcf")
    //        let attri = NSAttributedString.init(string: text, attributes: [NSFontAttributeName:font,NSForegroundColorAttributeName:textColor])
    //        return attri
    //    }
    override func imageAnimation(forEmptyDataSet scrollView: UIScrollView!) -> CAAnimation! {
        
        let animation = CABasicAnimation.init(keyPath: "transform")
        animation.fromValue = NSValue.init(caTransform3D: CATransform3DIdentity)
        animation.toValue = NSValue.init(caTransform3D: CATransform3DMakeRotation(CGFloat(M_PI * 2.0), 0.0, 0.0, 1.0))
        animation.duration = 0.25;
        animation.isCumulative = true;
        animation.repeatCount = MAXFLOAT;
        return animation;
    }
    
    override func image(forEmptyDataSet scrollView: UIScrollView!) -> UIImage! {
        if isLoading {
            return UIImage.init(named: "loading")
        }
        return UIImage.init(named: "empty")
    }
    
//    override func buttonTitle(forEmptyDataSet scrollView: UIScrollView!, for state: UIControlState) -> NSAttributedString! {
//        let text = "点击刷新"
//        let font = UIFont.systemFont(ofSize: 16.0)
//        let textColor = UIColor.init(hexString: (state == UIControlState.normal) ? "05adff" : "6bceff")
//        return NSAttributedString.init(string: text, attributes: [NSForegroundColorAttributeName:textColor,NSFontAttributeName:font])
//    }
    
    override func emptyDataSet(_ scrollView: UIScrollView!, didTap button: UIButton!) {
        isLoading = true;
        DispatchQueue.main.asyncAfter(deadline:.now() + 2.0) {
            self.isLoading = false
        }
    }
    
    
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
