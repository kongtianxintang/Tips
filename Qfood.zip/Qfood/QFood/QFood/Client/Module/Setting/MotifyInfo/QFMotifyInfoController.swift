/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:修改信息
 * Others:todo 逻辑
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import TZImagePickerController


class QFMotifyInfoController: QFBaseViewController,QFCheckBoxDelegate,TZImagePickerControllerDelegate{

    @IBOutlet weak var headerIcon: UIButton!
    @IBOutlet weak var checkbox: QFCheckBox!
    @IBOutlet weak var height: UIButton!
    @IBOutlet weak var birthday: UIButton!
    @IBOutlet weak var nickname: UITextField!
    var motifyBlock:(()->Void)?
    private  lazy var checks:[(radio:String,normal:String,name:String)] = [("checkbox-radio","checkbox-normal","女"),("checkbox-radio","checkbox-normal","男")]
    
    //上传头像成功后返回的路径
    private var picPath:String?
    //性别
    private var gender:String?
    //身高
    private var user_height:Int?
    //生日
    private var born:Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkbox.delegate = self
        configSubviews()
        title = "修改信息"
    }
    
    
    private func configSubviews(){
        nickname.layer.borderColor = UIColor.textInputBackground.cgColor
        birthday.layer.borderColor = UIColor.textInputBackground.cgColor
        height.layer.borderColor = UIColor.textInputBackground.cgColor
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    //选择头像 todo:上传逻辑 选取成功后逻辑
    @IBAction func didClickPickHeaderImage(_ sender: UIButton) {
        let pick = TZImagePickerController.init(maxImagesCount: 1, delegate: self)
        present(pick!, animated: true, completion: nil)
    }
    
    //保存数据
    @IBAction func didClickSaveInfo(_ sender: UIButton) {
        
        if let login = Login.fetchLogin() {
            var body = ["token":login.token!,"user_id":login.user_id!]
            
            //头像
            if picPath != nil {
                body.updateValue(picPath!, forKey: "user_avatar")
            }
            //昵称
            if let nickname = nickname.text{
                if nickname.characters.count > 0 {
                    body.updateValue(nickname, forKey: "user_nikname")
                }
            }
            //性别
            if gender != nil {
                body.updateValue(gender!, forKey: "sex")
            }
            
            //身高
            if user_height != nil {
                body.updateValue("\(user_height!)", forKey: "height")
            }
            
            //生日
            if born != nil {
                body.updateValue(born!.stringValue(formatter: "yyyy-MM"), forKey: "birthday")
            }
            
            
            QFNetworking.shared.post(url: QF_EDIT_USER, body: body, successHandler: {[unowned self] (json) in
                if self.motifyBlock != nil{
                    self.motifyBlock!()
                }
                let _ = self.navigationController?.popViewController(animated: true)
                
            }, failureHandler: nil)
            
        }
        
       
        
    }
    
    //更新出生年月
    @IBAction func didClickUpdateBirthday(_ sender: UIButton) {
        let datepick = QFBirthdayController()
        datepick.showDatePick()
        datepick.pickDateBlock = {[unowned self](date:Date) in
            self.born = date
            self.birthday.setTitle(date.stringValue(formatter: "yyyy-MM"), for: .normal)
        }
    }
    
    //更新身高
    @IBAction func didClickUpdateHeight(_ sender: UIButton) {
        
        let height = QFHeightController()
        height.showHeightPick()
        height.pickHeight = { [unowned self](userHeight:Int) in
            self.user_height = userHeight
            self.height.setTitle("\(userHeight)", for: .normal)
        }
    }
    
    
    
    //qfcheckbox的代理方法
    func numberOfSections() -> Int {
        return 1
    }
    
    func checkbox(numberOfItemsInSection section: Int) -> Int {
        return checks.count
    }
    
    func checkbox(checkbox: QFCheckBox, cellForItem indexPath: IndexPath) -> UICollectionViewCell {
        let cell = checkbox.dequeueReusablecell(cellForItemAt: indexPath) as! QFCheckBoxCell
        let info = checks[indexPath.row]
        cell.dec.text = info.name
        cell.icon.image = UIImage.init(named: info.normal)
        return cell
    }
    
    func checkbox(checkbox: QFCheckBox, didSelectItemAt indexPath: IndexPath) {
        let cell = checkbox.cellForItem(at: indexPath) as? QFCheckBoxCell
        if cell != nil {
            let info = checks[indexPath.row]
            cell!.icon.image = UIImage.init(named: info.radio)
            gender = indexPath.row == 0 ? "2":"1"
        }
    }
    
    func checkbox(checkbox: QFCheckBox, didDeselectItemAt indexPath: IndexPath) {
        let cell = checkbox.cellForItem(at: indexPath) as? QFCheckBoxCell
        if cell != nil {
            let info = checks[indexPath.row]
            cell!.icon.image = UIImage.init(named: info.normal)
        }
    }
    
    
    func imagePickerController(_ picker: TZImagePickerController!, didFinishPickingPhotos photos: [UIImage]!, sourceAssets assets: [Any]!, isSelectOriginalPhoto: Bool) {
        
        let icon = photos[0]
        headerIcon.setImage(icon, for: .normal)
        headerIcon.setTitle(nil, for: .normal)
        
        //上传到服务器
        if  let data = UIImageJPEGRepresentation(icon, 0.6) {
            let m = QFUpYunManager()
            
            m.uploader(bucketType: QFBucktNameType.Avatar, fileData: data, successblock: {[unowned self](path:String) in
                self.picPath = path
            })
            
        }
    }
}
