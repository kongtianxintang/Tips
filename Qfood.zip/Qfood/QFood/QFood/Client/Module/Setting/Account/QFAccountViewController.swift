/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:更换手机页
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import CoreData


class QFAccountViewController: QFBaseViewController {

    @IBOutlet weak var telephoneBackground: UIView!
    @IBOutlet weak var telephone: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configView()
        
    }

    
    private func configView(){
        title = "账号管理"
        telephoneBackground.layer.borderColor = UIColor.textInputBackground.cgColor
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //更换手机号
    @IBAction func didClickUpdateTelephone(_ sender: UIButton) {
        debugPrint(#function)
        
    }
    
    //退出
    @IBAction func didClickSinOut(_ sender: UIButton) {
        
        let _ = User.contextDelete()
        
        guard let result = QFDatabase.shared.fetchedResultsController(with: "Login", sortKey: "token") else{
            
            //数据库报错
            assertionFailure("数据库报获取到的result报错")
            return
        }
        
        do {
            try result.performFetch()
            let objs = result.fetchedObjects
            
            if objs != nil, objs!.count > 0 {
                
                let context = QFDatabase.shared.createContext()!
                for item in objs! {
                    context.delete(item as! NSManagedObject)
                }
                do {
                    try context.save()
                    QFManagerDisplay().displayLogin()
                } catch  {
                    assertionFailure("\(error)")
                }
            }
        } catch let error {
            assertionFailure("\(error)")
        }
        
        
        
        
        
        
    }
    
    //修改密码
    @IBAction func didClickMotifyPassword(_ sender: UIButton) {
        let motify = QFModifyController()
        show(motify, sender: nil)
        
    }

}
