/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/20
 * QQ/Tel/Mail:
 * Description:我的方案
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SwiftyJSON

class QFMyPlanController: QFBaseViewController,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var planBackground: UIView!
    @IBOutlet weak var planStateBackground: UIView!
    @IBOutlet weak var planComplateCount: UILabel!
    @IBOutlet weak var planComlateProgress: UILabel!
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var overview: UILabel!
    @IBOutlet weak var planButton: UIButton!
    
    
    private let reusId = "setting_tableview_cell"
    private var jsons:[JSON]?{
        didSet{
            tableview.reloadData()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configSubviews()
        
        defalutData()
    }
    
    //#
    private func configSubviews(){
        title = "我的方案"
        planBackground.layer.borderColor = UIColor.textInputBackground.cgColor
        planStateBackground.layer.borderColor = UIColor.textInputBackground.cgColor
        tableview.register(UINib.init(nibName: "QFSettingTableViewCell", bundle: nil), forCellReuseIdentifier: reusId)
        tableview.estimatedRowHeight = 44
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    //#uitableview delegate 和 datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jsons == nil ? 0:jsons!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:reusId, for: indexPath) as! QFSettingTableViewCell
        let info = jsons![indexPath.row]
        let start = info["starte_time"].intValue
        let end = info["end_time"].intValue
        let startTime = Date.init(timeIntervalSince1970: TimeInterval(start))
        let endTime = Date.init(timeIntervalSince1970: TimeInterval(end))
        let startStr = startTime.stringValue(formatter: "yyyyMMdd")
        let endStr = endTime.stringValue(formatter: "yyyyMMdd")
        let temp = startStr + "-" + endStr
        cell.desc.text = temp
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //TODO:点击事件
    }
    
    //MARK:网络请求
    func fetachData(){
        
        if let login = Login.fetchLogin() {
            
            let body = ["token":login.token!,"user_id":login.user_id!,"task_logId":login.task_logId] as [String : Any]
            
            QFNetworking.shared.post(url: QF_PLAN_INFO, body: body, successHandler: {[unowned self](json:JSON) in
                self.configPlan(json: json)
            }, failureHandler: nil)
            
        }
    }
    
    //MARK:根据网络数据设置方案描述
    func configPlan(json:JSON){
    
        let start = json["starte_time"].intValue
        jsons = json["historyLog"].arrayValue
        
        //方案还未开始
        if start > 0 {
        
            overview.isHidden = true
            planButton.isHidden = false
            
        //已经开始
        }else{
            
            planButton.isHidden = true
            overview.isHidden = false
            //
            let today = json["today"].intValue //今天是该方案的第几天
            let remainingDay = json["remainingDay"].intValue //该方案的剩余天数
            let taskStatusCount = json["taskStatusCount"].intValue //完成多少个任务
            let complete = json["complete"].floatValue //后台已经计算过 完成度 eg:4.4%
            
            
            let normal = [NSForegroundColorAttributeName:UIColor.black,NSFontAttributeName:UIFont.systemFont(ofSize: 17)]
            let drak = [NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground,NSFontAttributeName:UIFont.boldSystemFont(ofSize: 17)]
            
            //完成任务数
            let completecount = NSMutableAttributedString.init(string: "完成任务 : 个", attributes:normal)
            let drakcomplete = NSAttributedString.init(string: " \(taskStatusCount) ", attributes: drak)
            completecount.insert(drakcomplete, at: completecount.length - 1)
            planComplateCount.attributedText = completecount
            
            //方案完成度
            let completeprogress = NSMutableAttributedString.init(string: "方案完成度 : %", attributes: normal)
            let drakprogress = NSAttributedString.init(string: " \(complete) ", attributes: drak)
            completeprogress.insert(drakprogress, at: completeprogress.length - 1)
            planComlateProgress.attributedText = completeprogress
            
            //方案总体描述
            let overrview = NSMutableAttributedString.init(string: "方案进行中\n", attributes: [NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground,NSFontAttributeName:UIFont.boldSystemFont(ofSize: 20)])
            let planday = NSMutableAttributedString.init(string: "今天是方案第天,", attributes: normal)
            let planday1 = NSAttributedString.init(string: " \(today) ", attributes: drak)
            planday.insert(planday1, at: planday.length - 2)
            let planday2 = NSMutableAttributedString.init(string: "还剩天\n", attributes: normal)
            let planday3 = NSAttributedString.init(string: " \(remainingDay) ", attributes: drak)
            planday2.insert(planday3, at: planday2.length - 2)
            planday.append(planday2)
            
            
            //提醒话术
            let tips = "别忘了明天早上要完成数据测量任务哦"
            let tipsAttribute = NSAttributedString.init(string: tips, attributes: [NSForegroundColorAttributeName:UIColor.QFlightCellBackground,NSFontAttributeName:UIFont.systemFont(ofSize: 12)])
            
            //全部拼接上
            overrview.append(planday)
            overrview.append(tipsAttribute)
            
            //添加段落格式
            let paragraph = NSMutableParagraphStyle()
            paragraph.lineSpacing = 5
            paragraph.alignment = .center
            overrview.addAttributes([NSParagraphStyleAttributeName:paragraph], range: NSRange.init(location: 0, length: overrview.length))
            
            overview.attributedText = overrview
        }
    }
    
    @IBAction func didClickOpenPlan(_ sender: UIButton) {
        
        let scale = QFScaleController()
        scale.showScaleController()
        scale.callback = { (result:TFScaleResult) in
        
            //MARK:推出开启方案页面
            self.showOpenPlan(result: result)
            
        }
        scale.failureBlock = {[unowned self] in
            //MARK:去打开蓝牙
            self.bluetoothPoweredOffAction()
            
        }
    }
    
    
    private func defalutData(){
    
        
        guard let login = Login.fetchLogin() else {
            return
        }
        
        if login.task_logId == 0 {
        
            overview.isHidden = true
            planButton.isHidden = false
            
        }else{
            fetachData()
        }
        
        
    }
    
    private func bluetoothPoweredOffAction(){
        
        let alert = UIAlertController()
        let cancel = UIAlertAction.init(title: "取消", style: UIAlertActionStyle.cancel, handler: nil)
        let sure = UIAlertAction.init(title: "去开启蓝牙", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
            //MARK:去开启蓝牙
            let url = URL.init(string: "App-Prefs:root=Bluetooth")
            if nil != url {
                if UIApplication.shared.canOpenURL(url!){
                    UIApplication.shared.openURL(url!)
                }
            }
        }
        alert.addAction(cancel)
        alert.addAction(sure)
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    private func showOpenPlan(result:TFScaleResult){
        
        //TODO:逻辑～什么时候开启
        let alert = QFAlertViewController()
        
        //TODO:从蓝牙获取数据
        
        let normal = [NSForegroundColorAttributeName:UIColor.lightGray,NSFontAttributeName:UIFont.systemFont(ofSize: 15)]
        
        let number = [NSForegroundColorAttributeName:UIColor.gray,NSFontAttributeName:UIFont.systemFont(ofSize: 17)]
        
        let kg = [NSFontAttributeName:UIFont.systemFont(ofSize: 15),NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground]
        
        let current = NSMutableAttributedString.init(string: "您的当前体重:", attributes: normal)
        current.append(NSAttributedString.init(string: " \(result.weight) ", attributes: number))
        current.append(NSAttributedString.init(string: "KG\n", attributes: kg))
        
        
        let standard = NSMutableAttributedString.init(string: "您的标准体重:",attributes:normal)
        standard.append(NSAttributedString.init(string: " \(result.sw) ", attributes: number))
        standard.append(NSAttributedString.init(string: "KG", attributes: kg))
        
        current.append(standard)
        
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineSpacing = 5.0
        paragraph.alignment = .center
        
        current.addAttributes([NSParagraphStyleAttributeName:paragraph], range: NSRange.init(location: 0, length: current.length))
        
        alert.showPlan(attributedText: current)
        
        //true 开启方案 flase 不开启方案
        alert.clickBlock = { [unowned self] (flag:Bool,target:String?) in
            
            if flag {
                
                let json = ["Weight":result.weight,"muscle":result.muscleWeight,"Calorie":0,"VisceralFat":result.visceralFatPercentage,"Bone":result.boneWeight,"bmi":result.bmi,"water":result.waterWeight]
                
                let report = QFReportController()
                report.json = json
                report.targetWeight = target
                self.show(report, sender: nil)
                
            }else{
                
                QFManagerDisplay().loginOrRegisterSuccess()
            }
            
        }
        
    }
    
}
