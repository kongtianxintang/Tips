//
//  QFRecordview.swift
//  QFood
//
//  Created by 李伟 on 2017/3/8.
//  Copyright © 2017年 QFood. All rights reserved.
//

import UIKit

struct QFAxis {
    var xAxis = 0
    var yAxis = 0
    var status:Int8 = 0
}

class QFRecordview: UIView {


    private lazy var offset:CGFloat = 10.0
    
    lazy var xValues = ["第一周","第1天","第2天","第3天","第4天","第5天","第6天","第7天"]
    
    lazy var yValues = ["第一周","1","2","3","4"]
    
    var axiss:Array<QFAxis>?
    
    private lazy var weekLabel = UILabel()
    
    lazy var shapes = Array<CAShapeLayer>()
    
    var weekdesc:String?{
        didSet{
            weekLabel.text = weekdesc
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        
        if axiss == nil {
            return
        }
        
        //topline
        let topStart = CGPoint.init(x: bounds.origin.x + offset, y: bounds.origin.y + offset)
        let topEnd = CGPoint.init(x: bounds.maxX - offset, y: bounds.minY + offset)
//        debugPrint("rect=\(topStart,topEnd)")
        let topPath = UIBezierPath()
        topPath.move(to: CGPoint.init(x: rect.origin.x + offset, y: rect.origin.y))
        topPath.addLine(to: CGPoint.init(x: rect.maxX - offset, y: rect.origin.y))
        let topline = CAShapeLayer()
        topline.path = topPath.cgPath
        topline.lineWidth = 1
        topline.strokeColor = UIColor.QFlightCellBackground.cgColor
        
        
        layer.addSublayer(topline)
        
        
        //bootmeline
        let bottomStart = CGPoint.init(x: rect.minX + offset, y: rect.maxY - offset)
        
        let xAverage = (rect.width - offset * 2.0) / CGFloat(xValues.count)
        
        let yAverage = (rect.height - offset * 2.0) / CGFloat(yValues.count)
        
        
        
        for i in 0 ... xValues.count{
        
            let x = CGFloat(i) * xAverage
            let start = CGPoint.init(x: topStart.x + x, y: topStart.y)
            let end = CGPoint.init(x: topStart.x + x, y: bottomStart.y)
            
            if i == 0 {
                
                weekLabel.frame = CGRect.init(origin: start, size: CGSize.init(width: xAverage, height: yAverage))
                
                weekLabel.text = weekdesc
                weekLabel.textAlignment = .center
                weekLabel.font = UIFont.systemFont(ofSize: 12)
                weekLabel.textColor = UIColor.brown
                addSubview(weekLabel)
                
            }else{
            
                let path = UIBezierPath()
                path.move(to: start)
                path.addLine(to: end)
                let shape = CAShapeLayer()
                shape.lineWidth = 1
                shape.strokeColor = UIColor.QFlightCellBackground.cgColor
                shape.path = path.cgPath
                layer.addSublayer(shape)
                
                if i == xValues.count {
                    
                }else{
                    let label = UILabel()
                    label.textAlignment = .center
                    label.font = UIFont.systemFont(ofSize: 10)
                    label.text = "第\(i)天"
                    label.frame = CGRect.init(origin: start, size: CGSize.init(width: xAverage, height: yAverage))
                    addSubview(label)
                }
            }
        }
        
        for i in 0 ... yValues.count{
        
            if i == 0 {
                
            }else{
            
                let y = CGFloat(i) * yAverage
                let start = CGPoint.init(x: topStart.x , y: topStart.y + y)
                let end = CGPoint.init(x: topEnd.x , y: topStart.y + y)
                let path = UIBezierPath()
                path.move(to: start)
                path.addLine(to: end)
                let shape = CAShapeLayer()
                shape.lineWidth = 1
                shape.strokeColor = UIColor.QFlightCellBackground.cgColor
                shape.path = path.cgPath
                layer.addSublayer(shape)
                
                if i == yValues.count {
                    
                }else{
                    let label = UILabel()
                    label.textAlignment = .center
                    label.font = UIFont.systemFont(ofSize: 12)
                    label.text = "\(i)"
                    label.frame = CGRect.init(origin: start, size: CGSize.init(width: xAverage, height: yAverage))
                    addSubview(label)
                }
            }
        }
        
        
        
        
        
        if axiss != nil {
            
            for item in axiss! {
                let shape = CAShapeLayer()
                let point = CGPoint.init(x:topStart.x + CGFloat(item.xAxis) * xAverage, y:topStart.y + CGFloat(item.yAxis) * yAverage)
                let size = CGSize.init(width: xAverage, height: yAverage)
                let path = UIBezierPath.init(rect: CGRect.init(origin: point, size: size))
                shape.path = path.cgPath
                shape.lineWidth = 1
                shape.strokeColor = UIColor.white.cgColor
                shape.fillColor = item.status == 0 ? UIColor.red.cgColor : UIColor.QFLightYellow.cgColor
                layer.addSublayer(shape)
                shapes.append(shape)
            }
            
        }else{
//            var axis = Array<QFAxis>()
//            for i in 0 ..< xVelues.count - 1{
//                
//                for j in 0 ..< yVelues.count - 1{
//                    
//                    var ax = QFAxis()
//                    ax.xAxis = i
//                    ax.yAxis = j
//                    axis.append(ax)
//                }
//            }
//            for item in axis {
//                let shape = CAShapeLayer()
//                let point = CGPoint.init(x:topStart.x + CGFloat(item.xAxis + 1) * xAverage, y:topStart.y + CGFloat(item.yAxis + 1) * yAverage)
//                let size = CGSize.init(width: xAverage, height: yAverage)
//                let path = UIBezierPath.init(rect: CGRect.init(origin: point, size: size))
//                shape.path = path.cgPath
//                shape.lineWidth = 1.5
//                let ar = arc4random() % 2
//                let backcolor = ar == 1 ? UIColor.QFLightYellow : UIColor.red
//                shape.strokeColor = UIColor.white.cgColor
//                shape.fillColor = backcolor.cgColor
//                layer.addSublayer(shape)
//            }
//x
        }
        
        
        
    }
    
    
    
}
