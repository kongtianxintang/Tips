/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:自定义线性图
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import SnapKit


protocol QFWeightLineClickIndex:NSObjectProtocol{
    func didClickIndex(index:Int)
}
class QFWeightlineView: UIView {

    
    weak var delegate:QFWeightLineClickIndex?
    
    private let reuseId = "linecell"
    
    //x轴总元素有几个
//    var XaxisCount:Int = 1
    
    //y轴总共有几个元素
//    var YaxisCount:Int = 1
    
    var yVules:[Float]?
    
    var stands:Int = 100;
    
    
    
    var currentPoint:CGPoint?
    
    private lazy var layers = Array<CAShapeLayer>()
    
    private lazy var points = Array<CGPoint>()
    
    
    private lazy var offset:CGFloat = 20.0
    
    private var lastPoint:CGPoint?
    
    private lazy var replicator = CAShapeLayer()
    
    private lazy var descLabel = UILabel()
    
//    private lazy var scrollView = UIScrollView()
    
    override func awakeFromNib() {
        
//        self.addSubview(scrollView)
//        scrollView.snp.makeConstraints { (make) in
//            make.edges.equalTo(UIEdgeInsets.init(top: self.offset, left: self.offset, bottom: self.offset, right: self.offset))
//        }

        self.addSubview(descLabel)
        descLabel.text = "暂时无数据"
        descLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.size.equalTo(CGSize.init(width: 100, height: 50))
        }
        
        
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        
        
        //topline
        let topStart = CGPoint.init(x: bounds.origin.x + offset, y: bounds.origin.y + offset)
        let topEnd = CGPoint.init(x: bounds.maxX - offset, y: bounds.minY + offset)
//        debugPrint("rect=\(topStart,topEnd)")
        let topPath = UIBezierPath()
        topPath.move(to: topStart)
        topPath.addLine(to: topEnd)
        let topline = CAShapeLayer()
        topline.path = topPath.cgPath
        topline.lineWidth = 1
        topline.strokeColor = UIColor.QFlightCellBackground.cgColor
        
        layer.addSublayer(topline)
        
//        layer.addSublayer(topline)
        
        
        //bootmeline
        let bottomStart = CGPoint.init(x: rect.minX + offset, y: rect.maxY - offset)
        let bottomEnd = CGPoint.init(x: rect.maxX - offset, y: rect.maxY - offset)
        let bottompath = UIBezierPath()
        bottompath.move(to: bottomStart)
        bottompath.addLine(to: bottomEnd)
        let bottomLine = CAShapeLayer()
        bottomLine.path = bottompath.cgPath
        bottomLine.strokeColor = UIColor.QFlightCellBackground.cgColor
        bottomLine.lineWidth = 1
        
        layer.addSublayer(bottomLine)
        
        if yVules == nil {
            
            descLabel.isHidden = false
            return
        }
        if yVules!.count <= 0 {
            descLabel.isHidden = false
            return
        }
        
        descLabel.isHidden = true
        guard let tempmax = yVules!.max() else {
            return
        }
        guard let tempMin = yVules!.min() else {
            return
        }
        let max = tempmax + 50.0
        let min = tempMin - 50.0 > 0 ? tempMin - 50.0 : 0
        let dis = max - min
        let yAverage = rect.height / CGFloat(dis)
        let xAverage:CGFloat = (rect.width - 2 * offset) / 8
        
        
        
        let path = UIBezierPath()
        let line = CAShapeLayer()
        line.lineWidth = 1
        line.strokeColor = UIColor.red.cgColor
        
        for i in 0 ..< yVules!.count {
            
            
            var endPoint:CGPoint!
//            var controlPoint:CGPoint!
            let temp = yVules![i]

            var y = rect.maxY - CGFloat(temp - min) * yAverage
            if y >= rect.maxY - offset{
                y -= offset * 2.0
            }else if y <= rect.minY{
                y += offset * 2.0
            }else{
                
            }
            let x = rect.minX + CGFloat(i + 1) * xAverage
            
//            if x >= rect.maxX {
//                x -= offset * 2.0
//            }
            
            if lastPoint == nil {
                lastPoint = CGPoint.init(x: 0, y: rect.midY)
            }else{
//                endPoint = CGPoint.init(x: x, y: y)
                
            }
            
            
            
            endPoint = CGPoint.init(x: x, y: y)
            path.move(to: lastPoint!)
//            path.addQuadCurve(to: endPoint, controlPoint: <#T##CGPoint#>)
            path.addLine(to: endPoint)
            lastPoint = endPoint
            points.append(endPoint)
            
        }
        let endPoint = CGPoint.init(x: rect.maxX, y: rect.midY)
        path.move(to: lastPoint!)
        path.addLine(to: endPoint)
        path.lineCapStyle = .round
        path.lineJoinStyle = .round
        line.path = path.cgPath
        layer.addSublayer(line)
        


        for i in 0 ..< points.count {
        
            let item = points[i]
            let path = UIBezierPath.init(arcCenter: item, radius: 5, startAngle: 0, endAngle: CGFloat(M_PI * 2.0), clockwise: true)
            let shape = CAShapeLayer()
            let start = CGPoint.init(x: item.x, y: bottomEnd.y)
            path.move(to: start)
            path.addLine(to: item)
            shape.path = path.cgPath
            shape.fillColor = UIColor.red.cgColor
            shape.lineWidth = 1
            
            let linepath = UIBezierPath()
            let end = CGPoint.init(x: item.x, y: item.y + 5)
            linepath.move(to: start)
            linepath.addLine(to: end)
            let indicate = CAShapeLayer()
            indicate.path = linepath.cgPath
            indicate.lineWidth = 1
            indicate.strokeColor = UIColor.lightGray.cgColor
            
            
            layer.addSublayer(shape)
            
            layer.addSublayer(indicate)
            
            layers.append(shape)
            
            let y = rect.maxY - offset
            let orgin = CGPoint.init(x: item.x - 15, y: y)
            let label = UILabel()
            label.frame = CGRect.init(origin: orgin, size: CGSize.init(width: 35.0, height: 20.0))
            label.numberOfLines = 0
            if i == 0 {
                label.text = "初始体重"
                label.font = UIFont.systemFont(ofSize: 8)
            }else{
                label.text = "\(i)周"
                label.font = UIFont.systemFont(ofSize: 12)
            }
            label.textAlignment = .center
            
            addSubview(label)
            
        }
        
        //动画
        let animation = CABasicAnimation()
        animation.keyPath = "strokeEnd"
        animation.duration = 2.0
        animation.fromValue = 0
        animation.toValue = 1
        line.add(animation, forKey:nil)
        
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first!
        let point = touch.location(in: self)

        let temppoint = points.first { (tpoint:CGPoint) -> Bool in
            let x = tpoint.x
            let max = x + 20.0
            let min = x - 20.0
            if point.x < max && point.x > min{
                return true
            }
            return false
        }
        
        if let temp  = temppoint {
            if let index  = points.index(of: temp) {
                if index > layers.count - 1 {
                    return
                }
                let templayer = layers[index]
                templayer.fillColor = UIColor.blue.cgColor
                for i in 0 ..< layers.count{
                    let sub = layers[i]
                    if i == index {
                        sub.fillColor = UIColor.QFNavigationBarBackground.cgColor
                    }else{
                        sub.fillColor = UIColor.red.cgColor
                    }
                }
                //代理协议传值
                if delegate != nil {
                    delegate!.didClickIndex(index: index)
                }
            }
        }
    }
    
//    deinit {
//        debugPrint("deinit \(self.classForCoder)")
//    }
    
}
