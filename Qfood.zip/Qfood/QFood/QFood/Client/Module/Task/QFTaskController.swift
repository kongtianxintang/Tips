/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:我的任务～～
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit
import Charts
import TZImagePickerController
import SwiftyJSON

struct QFBodyData {
    var bmi:Float = 0.0
    var water:Float = 0.0
    var weight:Float = 0.0
    var visceralFat:Float = 0.0
    var calorie:Float = 0.0
    var bone:Float = 0.0
    var muscle:Float = 0.0
}
class QFTaskController: QFBaseViewController ,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UITabBarControllerDelegate,TZImagePickerControllerDelegate,QFWeightLineClickIndex{

    @IBOutlet weak var linechart: QFWeightlineView!
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var recordview: QFRecordview!
    
    @IBOutlet weak var overview: UILabel!
    
    @IBOutlet weak var mealCollectionview: UICollectionView!
    
    @IBOutlet weak var mealTipsbackview: UIView!
    private let mealcellreusid = "mealcell"
    private let tipsReusid = "QFAskCell"
    //选中的时间点～ 早餐 ～ 中餐 ～下午茶 ～晚餐
    @IBOutlet weak var goalButton: UIButton!
    @IBOutlet weak var alreadyButton: UIButton!
    @IBOutlet weak var progressButton: UIButton!
    @IBOutlet weak var weightLabel: UILabel!
    @IBOutlet weak var BMILabel: UILabel!
    
    private lazy var bodys = Array<QFBodyData>()
    
    //任务
    private var tasks:[JSON]?{
        didSet{
            if tasks != nil{
                for i:Int in 0 ..< tasks!.count {
                    let item = tasks![i]
                    if let pics = item["task_pics"].arrayObject{
                        var temp = Array<(path:String?,img:UIImage?,isEdit:Bool)>()
                        for pic in pics {
                            temp.append((pic as? String,nil,true))
                        }
                        //MARK:默认图片
                        let add = UIImage.init(named: "add")
                        switch i {
                        case 0:
                            if pics.count <= 0 {
                                temp.append((nil,add,false))
                            }
                        case 1:
                            if pics.count <= 1 {
                                temp.append((nil,add,false))
                            }
                        case 2:
                            if pics.count <= 0 {
                                temp.append((nil,add,false))
                            }
                        case 3:
                            if pics.count <= 1 {
                                temp.append((nil,add,false))
                            }
                        default:
                            temp.append((nil,add,false))
                            break;
                        }
                       let _ = mealDict.updateValue(temp, forKey: i)
                    }
                }
                let task = tasks![selectIndex.row]
                taskDesc(task: task)
            }
        }
    }
    
    private lazy var mealDict = Dictionary<Int,Any>()
    
    //默认时间段
    private lazy var selectIndex:IndexPath = {
        var index:IndexPath?
        let hour = Calendar.current.component(.hour, from: Date())
        if hour >= 0 && hour <= 9 {
            index = IndexPath.init(row: 0, section: 0)
        }else if hour > 9 && hour < 13 {
            index = IndexPath.init(row: 1, section: 0)
        }else if hour >= 13 && hour <= 16{
            index = IndexPath.init(row: 2, section: 0)
        }else{
            index = IndexPath.init(row: 3, section: 0)
        }
        return index!
    }()
    
    //早中晚
    private lazy var mealInfos:[(name:String,desc:String,normal:UIColor,unfold:UIColor,unfoldImageName:String)] = {
        
        var list = Array<(name:String,desc:String,normal:UIColor,unfold:UIColor,unfoldImageName:String)>()
        let breakfast = ("早餐","7:00-9:00",UIColor.QFBreakfast,UIColor.QFBreakfast,"breakfast")
        list.append(breakfast)
        let lunch = ("午餐","11:30-12:30",UIColor.QFLunch,UIColor.QFLunch,"lunch")
        list.append(lunch)
        let afternoon = ("加餐","14:30-16:00",UIColor.QFAfternoon,UIColor.QFAfternoon,"afternoon")
        list.append(afternoon)
        let supper = ("晚餐","17:30-19:30",UIColor.QFSupper,UIColor.QFSupper,"supper")
        list.append(supper)
        return list
    
    }()
    
    private lazy var mealImgs:[(img:UIImage?,isEdit:Bool)] = {
    
    
        var list = Array<((img:UIImage?,isEdit:Bool))>()
        
        let add = UIImage.init(named: "add")
        
        list.append((add,false))
        
        return list
    }()
    
    //collectionview
    private let reusHeaderID = "mealHeader"
    private var mealTips:String = "暂时没有数据"
    //第一次上传的图片地址～针对午餐和晚餐
    private var pictruePath:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBarController?.delegate = self
        tabBarController?.title = "我的任务"
        
        
        linechart.delegate = self
        
        
        configtableview()
        configCollectionview()

        
        fetchData()
        
    }

    //MARK:概要描述
    private func configOverview(json:JSON){
    
        //TODO:网络获取到数据 处理
        
        let phase = json["phase"].stringValue
        let weekstr = json["week"].stringValue
        let daystr = json["day"].stringValue
//        debugPrint("期=\(phase) 周=\(weekstr) 天=\(daystr)")
        let attributes = [NSForegroundColorAttributeName:UIColor.QFNavigationBarBackground,NSFontAttributeName:UIFont.boldSystemFont(ofSize: 20)]
        let goal = NSAttributedString.init(string:phase, attributes: attributes)
        
        let week = NSAttributedString.init(string:weekstr, attributes: attributes)
        
        let day = NSAttributedString.init(string:daystr, attributes: attributes)
        
        let mutabl = NSMutableAttributedString.init(attributedString: goal)
        
        let normal = [NSForegroundColorAttributeName:UIColor.gray,NSFontAttributeName:UIFont.boldSystemFont(ofSize: 20)]
        mutabl.append(NSAttributedString.init(string: ":第 ", attributes: normal))
        mutabl.append(week)
        let p2 = NSAttributedString.init(string: " 周 第 ", attributes: normal)
        mutabl.append(p2)
        
        mutabl.append(day)
        
        let p3 = NSAttributedString.init(string: " 天", attributes: normal)
        
        mutabl.append(p3)
        
        overview.attributedText = mutabl
        recordview.weekdesc = "第\(weekstr)周"
    
    }
    
    //设置目标 已经 进度 button的字
    private func configGoalbutton(json:JSON){
    
        let goalstr = json["target_weight"].stringValue
        let goal = NSMutableAttributedString.init(string:"-" + goalstr, attributes: [NSFontAttributeName:UIFont.boldSystemFont(ofSize: 20),NSForegroundColorAttributeName:UIColor.QFdeviceValidText])
        let kg = NSAttributedString.init(string: "kg", attributes: [NSForegroundColorAttributeName:UIColor.QFdeviceValidText,NSFontAttributeName:UIFont.systemFont(ofSize: 15)])
        goal.append(kg)
        goalButton.setAttributedTitle(goal, for: .normal)
        
        //TODO:已减多少斤需要蓝牙数据
        let last = bodys.last
        let first = bodys.first
        var weight:Float = 0
        var weightStr:String?
        if nil != last, nil != first {
            weight = last!.weight - first!.weight
        }
        if weight >= 0 {
            weightStr = "+\(weight)"
        }else{
            weightStr = "\(weight)"
        }
        
        let have = NSMutableAttributedString.init(string: weightStr!, attributes: [NSFontAttributeName:UIFont.boldSystemFont(ofSize: 20),NSForegroundColorAttributeName:UIColor.lightText])
        let havekg = NSAttributedString.init(string: "kg", attributes: [NSFontAttributeName:UIFont.systemFont(ofSize: 15),NSForegroundColorAttributeName:UIColor.lightText])
        have.append(havekg)
        alreadyButton.setAttributedTitle(have, for: .normal)
        
        let progressstr = json["complete"].stringValue
        let progress = NSMutableAttributedString.init(string: progressstr, attributes: [NSFontAttributeName:UIFont.boldSystemFont(ofSize: 20),NSForegroundColorAttributeName:UIColor.QFProgress])
        let progresskg = NSAttributedString.init(string: "%", attributes: [NSFontAttributeName:UIFont.systemFont(ofSize: 15),NSForegroundColorAttributeName:UIColor.QFProgress])
        progress.append(progresskg)
        
        progressButton.setAttributedTitle(progress, for: .normal) 
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //#tableview
    private func configtableview(){
        tableview.register(UINib.init(nibName: "QFMealCell", bundle: nil), forCellReuseIdentifier:mealcellreusid)
    }
    //#tableview delegate method
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mealInfos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: mealcellreusid, for: indexPath) as! QFMealCell
        
        //是否打开 ~ true 打开 flase 折叠
        let isunfold = indexPath == selectIndex
        cell.foldDate.isHidden = isunfold
        cell.unfoldBackview.isHidden = !isunfold
        
        let info = mealInfos[indexPath.row]
        
        if isunfold {
            mealTipsbackview.backgroundColor = info.unfold
        }
        
        cell.unfoldDate.text = info.desc
        cell.foldDate.text = info.desc
        cell.unfoldBackview.backgroundColor = info.unfold
        cell.backgroundColor = info.normal
        cell.mealIcon.image = UIImage.init(named: info.unfoldImageName)
        cell.mealName.text = info.name
        cell.mealName.textColor = info.unfold
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath == selectIndex {
            return tableView.bounds.size.height / 5 * 2
        }
        return tableView.bounds.size.height / 5
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //已经是选择
        if indexPath == selectIndex {
            return
        }
        tableview.beginUpdates()
        //刷新动画
        tableview.reloadRows(at: [selectIndex,indexPath], with: UITableViewRowAnimation.automatic)
        selectIndex = indexPath
        tableview.endUpdates()
        //MARK:去刷新右边的视图
        if tasks != nil {
            let task = tasks![indexPath.row]
            taskDesc(task: task)
        }
    }
    
    
    //#collectionview
    private func configCollectionview(){
        mealCollectionview.register(UINib.init(nibName: "QFAskCell", bundle: nil), forCellWithReuseIdentifier: tipsReusid)
        mealCollectionview.register(UINib.init(nibName: "QFMealReusableView", bundle: nil), forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: reusHeaderID)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if mealDict.keys.count > 0 { return 1 }
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let list = mealDict[selectIndex.row] as! Array<(path:String?,img:UIImage?,isEdit:Bool)>
        return list.count

    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: tipsReusid, for: indexPath) as! QFAskCell
        let list = mealDict[selectIndex.row] as! Array<(path:String?,img:UIImage?,isEdit:Bool)>
        let info = list[indexPath.row]
        //这是个add图
        if !info.isEdit {
           cell.icon.image = info.img
        }else{
            if info.path != nil {
                cell.icon.qfSet(with: info.path!, completionHandler: nil)
            }else{
                cell.icon.image = info.img
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let list = mealDict[selectIndex.row] as! Array<(path:String?,img:UIImage?,isEdit:Bool)>
        let info = list[indexPath.row]
        //是真的图片
        if info.isEdit {
            return
        }
        let pick = TZImagePickerController.init(maxImagesCount: 1, delegate: self)
        
        present(pick!, animated: true, completion: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let reuse = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: reusHeaderID, for: indexPath) as! QFMealReusableView
        reuse.desc.text = mealTips
        return reuse
    }
    
    
    //#tzimagepickcontroller delegate
    func imagePickerController(_ picker: TZImagePickerController!, didFinishPickingPhotos photos: [UIImage]!, sourceAssets assets: [Any]!, isSelectOriginalPhoto: Bool) {
        
        guard let login = Login.fetchLogin() else {
            return
        }
        guard let tempTasks  =  tasks else {
            return
        }
        if selectIndex.row >= tempTasks.count {
            return
        }
        guard let data = UIImageJPEGRepresentation(photos[0], 0.3) else {
            return
        }
        
        QFUpYunManager().uploader(bucketType:.FoodTaskPic, fileData: data) {[unowned self] (pic:String) in
            let task = tempTasks[self.selectIndex.row]
            let taskid = task["task_id"].stringValue
            
            do{
            
                let tempData = try JSONSerialization.data(withJSONObject: [pic], options: JSONSerialization.WritingOptions.init(rawValue: 0))
                if let swiftJson = String.init(data: tempData, encoding: .utf8){
                
                    let body = ["token":login.token!,"user_id":login.user_id!,"pics":swiftJson,"task_id":taskid]
                    
                    DispatchQueue.main.async {
                        QFNetworking.shared.post(url: QF_PERFORM_TASK, body: body, successHandler: { (json:JSON) in
//                            debugPrint("完成任务json=\(json)")
                            let day = task["day"].intValue - 1
                            let row = day * 4 + self.selectIndex.row
                            let shape = self.recordview.shapes[row]
                            shape.fillColor = UIColor.QFLightYellow.cgColor
                            self.pictruePath = pic
                            var list = self.mealDict[self.selectIndex.row] as! Array<(path:String?,img:UIImage?,isEdit:Bool)>
                            list.insert((nil,photos[0],true), at: 0)
                            
                            //判断是否多出 删除add图片
                            switch self.selectIndex.row {
                            case 0:
                                if list.count > 1 {
                                    let _ = list.removeLast()
                                }
                            case 1:
                                if list.count > 2 {
                                    let _ = list.removeLast()
                                }
                            case 2:
                                if list.count > 1 {
                                    let _ = list.removeLast()
                                }
                            default:
                                if list.count > 2 {
                                    let _ = list.removeLast()
                                }
                                break;
                            }
                            let _ = self.mealDict.updateValue(list, forKey: self.selectIndex.row)
                            DispatchQueue.main.async {
                                self.mealCollectionview.reloadData()
                            }
                        }, failureHandler: nil)
                    }
                }
            }catch{
                assertionFailure("拼接json字符串不成功")
            }
        }
    }
    
    
    //#descview
    //#UITabBarControllerDelegate
    //设置navigation title
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        let className = NSStringFromClass(viewController.classForCoder)
        switch className {
        case "QFood.QFTaskController":
            tabBarController.title = "我的任务"
            tabBarController.navigationItem.setRightBarButton((tabBarController as! QFTabBarViewController).rightBar, animated: true)
        case "QFood.QFQAController":
            tabBarController.title = "问答"
            tabBarController.navigationItem.setRightBarButton(nil, animated: true)
        default:
            tabBarController.title = "信息设置"
            tabBarController.navigationItem.setRightBarButton(nil, animated: true)
            break;
        }
    }
    
    //#三个button事件
    @IBAction func didClickGoalAction(_ sender: UIButton) {
        if linechart.isHidden{
            linechart.isHidden = false
            recordview.isHidden = true
        }
    }
    
    @IBAction func didClickProgressAction(_ sender: UIButton) {
        if recordview.isHidden{
            recordview.isHidden = false
            linechart.isHidden = true
        }
    }
    
    @IBAction func didClickAlreadyAction(_ sender: UIButton) {
        if linechart.isHidden{
            linechart.isHidden = false
            recordview.isHidden = true
        }
        
    }
    
    //MARK:网络获取数据
    func fetchData(){
        
        if let login = Login.fetchLogin() {
            
            let body = ["token":login.token!,"user_id":login.user_id!,"task_logId":login.task_logId] as [String : Any]
            
            QFNetworking.shared.post(url: QF_TASK, body: body, successHandler: {[unowned self] (json) in
//                debugPrint("首页数据成功回调=\(json)")
                self.configOverview(json: json)
                self.configWeightLine(json: json)
                self.configTasksCharts(json: json)
                self.tasks = json["tasks"].array
                self.configGoalbutton(json: json)
            }, failureHandler: nil)
        }
    }
    
    //MARK:设置体重线
    func configWeightLine(json:JSON){
    
    
        let list = json["userBodyData"].arrayValue
        
        for item in list {
            let info = item["body_data"]
            var data = QFBodyData()
            data.bmi = info["bmi"].floatValue
            data.water = info["water"].floatValue
            data.weight = info["Weight"].floatValue
            data.visceralFat = info["VisceralFat"].floatValue
            data.calorie = info["Calorie"].floatValue
            data.bone = info["Bone"].floatValue
            data.muscle = info["muscle"].floatValue
            bodys.append(data)
        }
        
        let yvalues = bodys.map { (data:QFBodyData) -> Float in
            return data.weight
        }
        
        linechart.yVules = yvalues
        linechart.setNeedsDisplay()
        
        if bodys.count > 0 {
            let body = bodys[0]
            weightLabel.text = "体重:\(Int(body.weight))kg"
            BMILabel.text = "BMI:\(Int(body.bmi))"
        }
    }
    
    
    //MARK:设置任务完成度
    func configTasksCharts(json:JSON){
    
        let list = json["task_status"].arrayValue
        var temp =  Array<QFAxis>()
        //数据格式:数组包含数组
        for item in list {
            let tasks = item.arrayValue
            for task in tasks {
                var axis = QFAxis()
                let type = task["type"].stringValue
                switch type {
                case "早餐":
                    axis.yAxis = 1
                case "午餐":
                    axis.yAxis = 2
                case "加餐":
                    axis.yAxis = 3
                default:
                    axis.yAxis = 4
                    break;
                }
                let day = task["day"].intValue
                axis.xAxis = day
                //TODO:状态部分逻辑未理清楚
                axis.status = task["task_status"].int8Value
                temp.append(axis)
            }
        }
        recordview.axiss = temp
        
        recordview.setNeedsDisplay()
        
    }
    
    
    //MARK:QFWeightLineClickIndex的代理协议
    func didClickIndex(index: Int) {
        let body = bodys[index]
        weightLabel.text = "体重:\(Int(body.weight))kg"
        BMILabel.text = "BMI:\(Int(body.bmi))"
    }
    
    //MARK:右边任务描述和图片
    private func taskDesc(task:JSON){
        if let content = task["content"].string {
            
            let width = mealCollectionview.bounds.width
            let size = content.boundingRect(with: CGSize.init(width: width, height: 1000.0), options:[.usesLineFragmentOrigin,.usesFontLeading], attributes: [NSFontAttributeName:UIFont.systemFont(ofSize: 17)], context: nil)
            let height = size.height + 40.0
            let flow = mealCollectionview.collectionViewLayout as! UICollectionViewFlowLayout
            flow.headerReferenceSize = CGSize.init(width: width, height: height)
            mealTips = content
            mealCollectionview.reloadData()
            
        }
    }
    
   

}
