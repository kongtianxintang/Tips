/***********************************************************
 * 版权所有,2017,MeFood.
 * Copyright(C),2017,MeFood co. LTD.All rights reserved.
 * project:Li
 * Author:
 * Date:  17/02/22
 * QQ/Tel/Mail:
 * Description:首页～套餐～提示
 * Others:
 * Modifier:
 * Reason:
 *************************************************************/

import UIKit

class QFMealCell: UITableViewCell {

    //打开状态背景
    @IBOutlet weak var unfoldBackview: UIView!
    //折叠状态时间
    @IBOutlet weak var foldDate: UILabel!
    
    //打开状态的时间
    @IBOutlet weak var unfoldDate: UILabel!
    @IBOutlet weak var mealName: UILabel!
    @IBOutlet weak var mealIcon: UIImageView!
    @IBOutlet weak var mealiconHeight: NSLayoutConstraint!
    @IBOutlet weak var mealiconWidth: NSLayoutConstraint!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

        let width = mealName.bounds.maxX + mealName.bounds.maxY + 5.0
        let startPoint = bounds.origin
        let midPoint = CGPoint.init(x: width, y: mealName.bounds.minY)
        let endPoint = CGPoint.init(x: mealName.bounds.minX, y: mealName.bounds.minY + width)

        
        let shape = CAShapeLayer()
        let path = UIBezierPath()
        path.move(to: startPoint)
        path.addLine(to: midPoint)
        path.addLine(to: endPoint)
        path.move(to: midPoint)
        path.addLine(to: endPoint)

        shape.fillColor = UIColor.white.cgColor
        shape.strokeColor = UIColor.clear.cgColor
        shape.lineWidth = 1
        
        shape.path = path.cgPath
        unfoldBackview.layer.addSublayer(shape)
        unfoldBackview.bringSubview(toFront: mealName)

    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    //适配图片大小
    override func layoutSubviews() {
        super.layoutSubviews()
        let height = unfoldDate.frame.minY - mealName.frame.maxY
        
        if height > 0 {
            mealiconHeight.constant = height
            mealiconWidth.constant = height
        }
        
    }
    

    
}
