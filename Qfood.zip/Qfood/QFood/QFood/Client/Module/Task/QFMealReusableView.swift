//
//  QFMealReusableView.swift
//  QFood
//
//  Created by 李伟 on 2017/3/26.
//  Copyright © 2017年 QFood. All rights reserved.
//

import UIKit

class QFMealReusableView: UICollectionReusableView {
    
    @IBOutlet weak var desc: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
